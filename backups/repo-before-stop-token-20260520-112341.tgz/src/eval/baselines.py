from __future__ import annotations

from dataclasses import dataclass

import torch

from src.data.schema import RetrievalBatch
from src.weaver.context import GraphContext
from src.weaver.nn.feature_encoder import EncodedFeatures
from src.weaver.state import State


@dataclass(frozen=True, slots=True)
class BaselineMasks:
    node_masks: torch.Tensor
    edge_masks: torch.Tensor


def random_baseline_masks(
    *,
    batch: RetrievalBatch,
    context: GraphContext,
    expand_budget: int,
    seed: int = 0,
) -> BaselineMasks:
    state = State.initial(
        context=context,
        budget=int(expand_budget),
        rollouts_per_graph=1,
    )
    generator = torch.Generator(device=context.device)
    generator.manual_seed(int(seed))

    for _ in range(int(expand_budget)):
        frontier = state.frontier(context)
        if frontier.is_empty:
            break

        rows: list[int] = []
        edges: list[int] = []
        for row in range(state.num_rows):
            positions = frontier.row_ids.eq(row).nonzero(as_tuple=False).flatten()
            if positions.numel() == 0:
                continue
            offset = torch.randint(
                int(positions.numel()),
                (1,),
                generator=generator,
                device=context.device,
            )
            pos = positions.index_select(0, offset).item()
            rows.append(row)
            edges.append(int(frontier.edge_ids[pos].item()))

        if not rows:
            break

        state.apply_edges_(
            context=context,
            row_ids=torch.tensor(rows, dtype=torch.long, device=context.device),
            edge_ids=torch.tensor(edges, dtype=torch.long, device=context.device),
        )

    return _state_masks(state)


def semantic_greedy_baseline_masks(
    *,
    batch: RetrievalBatch,
    context: GraphContext,
    features: EncodedFeatures,
    expand_budget: int,
) -> BaselineMasks:
    state = State.initial(
        context=context,
        budget=int(expand_budget),
        rollouts_per_graph=1,
    )

    for _ in range(int(expand_budget)):
        frontier = state.frontier(context)
        if frontier.is_empty:
            break

        edge_semantic = features.edge_relation_semantic.index_select(
            0,
            frontier.edge_ids.to(device=features.edge_relation_semantic.device),
        )
        query_semantic = features.query_semantic.index_select(
            0,
            state.row_to_graph.index_select(0, frontier.row_ids).to(
                device=features.query_semantic.device,
            ),
        )
        scores = (edge_semantic * query_semantic).sum(dim=1).to(device=context.device)

        rows: list[int] = []
        edges: list[int] = []
        for row in range(state.num_rows):
            positions = frontier.row_ids.eq(row).nonzero(as_tuple=False).flatten()
            if positions.numel() == 0:
                continue
            row_scores = scores.index_select(0, positions)
            best = positions[int(torch.argmax(row_scores).item())]
            rows.append(row)
            edges.append(int(frontier.edge_ids[best].item()))

        if not rows:
            break

        state.apply_edges_(
            context=context,
            row_ids=torch.tensor(rows, dtype=torch.long, device=context.device),
            edge_ids=torch.tensor(edges, dtype=torch.long, device=context.device),
        )

    return _state_masks(state)


def _state_masks(
    state: State,
) -> BaselineMasks:
    device = torch.device("cpu")
    return BaselineMasks(
        node_masks=state.node_mask.detach().to(device=device, dtype=torch.bool),
        edge_masks=state.edge_mask.detach().to(device=device, dtype=torch.bool),
    )


__all__ = [
    "BaselineMasks",
    "random_baseline_masks",
    "semantic_greedy_baseline_masks",
]
