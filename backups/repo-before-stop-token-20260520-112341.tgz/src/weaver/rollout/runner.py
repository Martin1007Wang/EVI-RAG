from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from src.data.schema import RetrievalBatch
from src.weaver.context import GraphContext
from src.weaver.nn.feature_encoder import EncodedFeatures
from src.weaver.policy import Policy
from src.weaver.rollout.engine import RolloutEngine
from src.weaver.rollout.replay import (
    ReplayBatch,
    ReplaySampleBudget,
    ReplaySource,
    transitions_from_rollouts,
)
from src.weaver.rollout.result import RolloutResult
from src.weaver.transitions import (
    TRANSITION_SOURCE_POLICY,
    TRANSITION_SOURCE_REPLAY,
    TransitionBatch,
)


@dataclass(frozen=True, slots=True)
class RolloutBatch:
    rollouts: tuple[RolloutResult, ...]
    transitions: TransitionBatch | None = None
    replay: ReplayBatch | None = None

    @property
    def num_rollouts(self) -> int:
        return len(self.rollouts)

    @property
    def num_transitions(self) -> int:
        if self.transitions is None:
            return 0
        return int(self.transitions.num_transitions)

    @property
    def has_transitions(self) -> bool:
        return self.num_transitions > 0

    @property
    def num_replay_trajectories(self) -> int:
        if self.replay is None:
            return 0
        return int(self.replay.num_trajectories)

    @property
    def num_replay_transitions(self) -> int:
        if self.replay is None:
            return 0
        return int(self.replay.num_transitions)

    @property
    def num_replay_terminal_transitions(self) -> int:
        if self.replay is None:
            return 0
        return int(self.replay.num_terminal_transitions)


@dataclass(frozen=True, slots=True)
class ReplayScheduleRow:
    until_progress: float
    policy_rollout: float
    replay_expand: float


@dataclass(frozen=True, slots=True)
class ReplaySchedule:
    rows: tuple[ReplayScheduleRow, ...]

    def weights_at(self, progress: float) -> ReplayScheduleRow:
        for row in self.rows:
            if progress <= row.until_progress:
                return row
        return self.rows[-1]


class RolloutRunner:
    """
    Runner around RolloutEngine.

    Inputs:
        policy
        batch
        context
        features

    The runner does not build GraphContext.
    The runner does not encode features.
    The runner does not own RolloutContext.
    The runner does not chunk rollouts.
    """

    def __init__(
        self,
        *,
        engine: RolloutEngine,
        train_num_rollouts: int,
        eval_num_rollouts: int,
        replay_source: ReplaySource | None = None,
        replay_schedule: ReplaySchedule | None = None,
        progress_fn: Callable[[], float] | None = None,
    ) -> None:
        self.engine = engine
        self.train_num_rollouts = int(train_num_rollouts)
        self.eval_num_rollouts = int(eval_num_rollouts)
        self.replay_source = replay_source
        self.replay_schedule = replay_schedule
        self.progress_fn = progress_fn or zero_progress

    def train_rollouts(
        self,
        *,
        policy: Policy,
        batch: RetrievalBatch,
        context: GraphContext,
        features: EncodedFeatures,
        temperature: float,
    ) -> RolloutBatch:
        budget = self.sample_budget(self.train_num_rollouts)

        rollouts = self.policy_rollouts(
            policy=policy,
            context=context,
            features=features,
            num_rollouts=budget.policy_rollout,
            temperature=temperature,
        )

        replay = self.replay_transitions(
            batch=batch,
            rollouts=rollouts,
            context=context,
            num_transitions=budget.replay_expand,
        )

        transitions = self.training_transitions(
            batch=batch,
            rollouts=rollouts,
            replay=replay,
            context=context,
        )

        return RolloutBatch(
            rollouts=rollouts,
            transitions=transitions,
            replay=replay,
        )

    def eval_rollouts(
        self,
        *,
        policy: Policy,
        context: GraphContext,
        features: EncodedFeatures,
        temperature: float,
        num_rollouts: int | None = None,
    ) -> tuple[RolloutResult, ...]:
        total = self.eval_num_rollouts if num_rollouts is None else int(num_rollouts)

        return self.policy_rollouts(
            policy=policy,
            context=context,
            features=features,
            num_rollouts=total,
            temperature=temperature,
        )

    def policy_rollouts(
        self,
        *,
        policy: Policy,
        context: GraphContext,
        features: EncodedFeatures,
        num_rollouts: int,
        temperature: float,
    ) -> tuple[RolloutResult, ...]:
        num_rollouts = int(num_rollouts)

        if num_rollouts <= 0:
            return ()

        return tuple(
            self.engine.sample_rollouts(
                policy=policy,
                context=context,
                features=features,
                num_rollouts=num_rollouts,
                temperature=temperature,
            )
        )

    def replay_transitions(
        self,
        *,
        batch: RetrievalBatch,
        rollouts: tuple[RolloutResult, ...],
        context: GraphContext,
        num_transitions: int,
    ) -> ReplayBatch | None:
        num_transitions = int(num_transitions)

        if num_transitions <= 0:
            return None

        if self.replay_source is None:
            raise RuntimeError("replay_source is required when replay_expand > 0.")

        return self.replay_source.sample_from_rollouts(
            batch=batch,
            context=context,
            rollouts=rollouts,
            num_trajectories=num_transitions,
        )

    def training_transitions(
        self,
        *,
        batch: RetrievalBatch,
        rollouts: tuple[RolloutResult, ...],
        replay: ReplayBatch | None,
        context: GraphContext,
    ) -> TransitionBatch | None:
        parts: list[TransitionBatch] = []

        policy_transitions = transitions_from_rollouts(
            rollouts=rollouts,
            budget=self.engine.expand_budget,
            context=context,
        )

        if policy_transitions is not None and policy_transitions.num_transitions > 0:
            parts.append(policy_transitions.with_source_id(TRANSITION_SOURCE_POLICY))

        if replay is not None and replay.num_transitions > 0:
            parts.append(replay.transitions.with_source_id(TRANSITION_SOURCE_REPLAY))

        if not parts:
            return None

        return TransitionBatch.concat_reindex_trajectories(parts)

    def sample_budget(self, total: int) -> ReplaySampleBudget:
        total = int(total)

        if self.replay_schedule is None:
            return ReplaySampleBudget(
                policy_rollout=total,
                replay_expand=0,
            )

        weights = self.replay_schedule.weights_at(
            progress=float(self.progress_fn()),
        )

        return allocate_replay_budget(
            total=total,
            policy_weight=weights.policy_rollout,
            replay_weight=weights.replay_expand,
        )


def allocate_replay_budget(
    *,
    total: int,
    policy_weight: float,
    replay_weight: float,
) -> ReplaySampleBudget:
    total = int(total)

    if total <= 0:
        return ReplaySampleBudget(
            policy_rollout=0,
            replay_expand=0,
        )

    policy_weight = float(policy_weight)
    replay_weight = float(replay_weight)
    weight_sum = policy_weight + replay_weight

    if weight_sum <= 0.0:
        raise ValueError("policy_weight and replay_weight cannot both be zero.")

    policy_raw = total * policy_weight / weight_sum
    replay_raw = total * replay_weight / weight_sum

    policy_count = int(policy_raw)
    replay_count = int(replay_raw)

    remainder = total - policy_count - replay_count

    if remainder > 0:
        if policy_raw - policy_count >= replay_raw - replay_count:
            policy_count += remainder
        else:
            replay_count += remainder

    return ReplaySampleBudget(
        policy_rollout=policy_count,
        replay_expand=replay_count,
    )


def zero_progress() -> float:
    return 0.0


__all__ = [
    "ReplaySchedule",
    "ReplayScheduleRow",
    "RolloutBatch",
    "RolloutRunner",
    "allocate_replay_budget",
]
