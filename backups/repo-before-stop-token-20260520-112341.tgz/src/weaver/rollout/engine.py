from __future__ import annotations

import torch

from src.weaver.context import GraphContext
from src.weaver.nn.feature_encoder import EncodedFeatures
from src.weaver.policy import Policy
from src.weaver.state import State

from .action import Action, sample_action
from .result import RolloutResult
from .trace import RolloutTrace


class RolloutEngine:
    """
    Vectorized finite-horizon rollout engine.

    Responsibilities:
        - initialize rollout State
        - enumerate frontier from State
        - call Policy
        - sample Action
        - write RolloutTrace
        - apply selected edge expansions

    Non-responsibilities:
        - construct GraphContext from RetrievalBatch
        - encode features
        - detach features
        - compute rewards
        - compute losses
        - own greedy/debug action modes
    """

    def __init__(self, expand_budget: int) -> None:
        self.expand_budget = int(expand_budget)

    def sample_rollouts(
        self,
        *,
        policy: Policy,
        context: GraphContext,
        features: EncodedFeatures,
        num_rollouts: int,
        temperature: float = 1.0,
    ) -> list[RolloutResult]:
        with torch.no_grad():
            fused = self.sample_fused_rollouts(
                policy=policy,
                context=context,
                features=features,
                rollouts_per_graph=int(num_rollouts),
                temperature=float(temperature),
            )

        return fused.split_by_rollout_id(
            rollouts_per_graph=int(num_rollouts),
        )

    def sample_fused_rollouts(
        self,
        *,
        policy: Policy,
        context: GraphContext,
        features: EncodedFeatures,
        rollouts_per_graph: int,
        temperature: float = 1.0,
    ) -> RolloutResult:
        state = State.initial(
            context=context,
            budget=self.expand_budget,
            rollouts_per_graph=int(rollouts_per_graph),
        )

        source_graph_id = state.row_to_graph.clone()
        num_rows = int(source_graph_id.numel())

        trace = RolloutTrace(
            R=num_rows,
            T=self.expand_budget + 1,
            device=context.device,
        )

        alive = torch.ones(
            num_rows,
            dtype=torch.bool,
            device=context.device,
        )

        for t in range(self.expand_budget + 1):
            active_rows = alive.nonzero(as_tuple=False).flatten()

            if active_rows.numel() == 0:
                break

            active_state = state.select_rows(active_rows)
            frontier = active_state.frontier(context)

            policy_out = policy(
                features=features,
                state=active_state,
                context=context,
                frontier=frontier,
            )

            action = sample_action(
                policy_out=policy_out,
                frontier=frontier,
                temperature=float(temperature),
            )

            trace.write_action(
                t=t,
                active_rows=active_rows,
                action=action,
            )

            if action.stop_rows.numel() > 0:
                alive[active_rows.index_select(0, action.stop_rows)] = False

            self.apply_expand_rows(
                state=state,
                active_rows=active_rows,
                action=action,
                context=context,
            )

        return RolloutResult.from_trace(
            trace=trace,
            source_graph_id=source_graph_id,
            expand_budget=self.expand_budget,
        )

    @staticmethod
    def apply_expand_rows(
        *,
        state: State,
        active_rows: torch.Tensor,
        action: Action,
        context: GraphContext,
    ) -> None:
        if action.expand_rows.numel() == 0:
            return

        rows = active_rows.index_select(0, action.expand_rows)

        state.apply_edges_(
            context=context,
            row_ids=rows,
            edge_ids=action.edge_ids,
        )


__all__ = [
    "RolloutEngine",
]
