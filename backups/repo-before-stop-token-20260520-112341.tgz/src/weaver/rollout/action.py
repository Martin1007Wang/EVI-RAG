from __future__ import annotations

from dataclasses import dataclass

import torch
from src.weaver.policy import PolicyOutput, flat_policy_log_probs
from src.weaver.state import Frontier

ROLLOUT_LOG_PROB_DTYPE = torch.float32


@dataclass(frozen=True, slots=True)
class Action:
    """
    One rollout-step action for active state rows.

    stop_rows:
        Local active-state rows that stop.

    stop_log_prob:
        log P(STOP | z) for stop_rows.
        Forced-stop rows use log probability 0.

    forced_stop:
        Whether each stop row was forced because no legal expansion exists
        or no further budget remains.

    expand_rows:
        Local active-state rows that expand one edge.

    edge_ids:
        Physical KG edge ids selected for expand_rows.

    expand_log_prob:
        log P(edge | z) for each selected expansion edge.
    """

    stop_rows: torch.Tensor
    stop_log_prob: torch.Tensor
    forced_stop: torch.Tensor

    expand_rows: torch.Tensor
    edge_ids: torch.Tensor
    expand_log_prob: torch.Tensor


def sample_action(
    *,
    policy_out: PolicyOutput,
    frontier: Frontier,
    temperature: float = 1.0,
) -> Action:
    """
    Draw one flat action per state row from {STOP} U Frontier(z).

    Rows with empty frontier are forced to STOP.
    """
    if temperature <= 0.0:
        raise ValueError(f"temperature must be positive, got {temperature}.")

    stop_logit = rollout_float(policy_out.stop_logit).view(-1)
    edge_logit = rollout_float(policy_out.edge_logit).view(-1)
    stop_log_prob, edge_log_prob = flat_policy_log_probs(
        stop_logit=stop_logit,
        edge_logit=edge_logit,
        frontier=frontier,
    )

    num_rows = int(stop_logit.numel())
    device = stop_logit.device
    dtype = stop_logit.dtype

    has_frontier = rows_with_frontier(
        row_ids=frontier.row_ids,
        num_rows=num_rows,
        device=device,
    )

    forced_rows = (~has_frontier).nonzero(as_tuple=False).flatten()
    candidate_rows = has_frontier.nonzero(as_tuple=False).flatten()

    stop_row_parts: list[torch.Tensor] = []
    stop_log_prob_parts: list[torch.Tensor] = []
    forced_stop_parts: list[torch.Tensor] = []

    expand_row_parts: list[torch.Tensor] = []
    expand_edge_parts: list[torch.Tensor] = []
    expand_log_prob_parts: list[torch.Tensor] = []

    if forced_rows.numel() > 0:
        stop_row_parts.append(forced_rows)
        stop_log_prob_parts.append(
            torch.zeros(
                forced_rows.numel(),
                dtype=dtype,
                device=device,
            )
        )
        forced_stop_parts.append(
            torch.ones(
                forced_rows.numel(),
                dtype=torch.bool,
                device=device,
            )
        )

    if candidate_rows.numel() > 0:
        sampled = sample_flat_action(
            stop_logit=stop_logit,
            edge_logit=edge_logit,
            stop_log_prob=stop_log_prob,
            edge_log_prob=edge_log_prob,
            frontier=frontier,
            rows=candidate_rows,
            temperature=float(temperature),
            num_rows=num_rows,
        )

        if sampled.stop_rows.numel() > 0:
            stop_row_parts.append(sampled.stop_rows)
            stop_log_prob_parts.append(sampled.stop_log_prob)
            forced_stop_parts.append(
                torch.zeros(
                    sampled.stop_rows.numel(),
                    dtype=torch.bool,
                    device=device,
                )
            )

        if sampled.expand_rows.numel() > 0:
            expand_row_parts.append(sampled.expand_rows)
            expand_edge_parts.append(sampled.edge_ids)
            expand_log_prob_parts.append(sampled.expand_log_prob)

    return Action(
        stop_rows=cat_long(stop_row_parts, device=device),
        stop_log_prob=cat_float(stop_log_prob_parts, device=device, dtype=dtype),
        forced_stop=cat_bool(forced_stop_parts, device=device),
        expand_rows=cat_long(expand_row_parts, device=device),
        edge_ids=cat_long(expand_edge_parts, device=device),
        expand_log_prob=cat_float(expand_log_prob_parts, device=device, dtype=dtype),
    )


@dataclass(frozen=True, slots=True)
class SampledFlatAction:
    stop_rows: torch.Tensor
    stop_log_prob: torch.Tensor
    expand_rows: torch.Tensor
    edge_ids: torch.Tensor
    expand_log_prob: torch.Tensor


def sample_flat_action(
    *,
    stop_logit: torch.Tensor,
    edge_logit: torch.Tensor,
    stop_log_prob: torch.Tensor,
    edge_log_prob: torch.Tensor,
    frontier: Frontier,
    rows: torch.Tensor,
    temperature: float,
    num_rows: int,
) -> SampledFlatAction:
    row_mask = torch.zeros(
        int(num_rows),
        dtype=torch.bool,
        device=rows.device,
    )
    row_mask.index_fill_(0, rows, True)

    keep = row_mask.index_select(0, frontier.row_ids)
    edge_row_ids = frontier.row_ids[keep]
    edge_ids = frontier.edge_ids[keep]
    sampling_edge_logits = edge_logit[keep] / temperature
    original_edge_log_prob = edge_log_prob[keep]

    local_edge_row_ids = remap_rows(
        row_ids=edge_row_ids,
        rows=rows,
        num_rows=num_rows,
    )

    sampling_stop_logits = stop_logit.index_select(0, rows) / temperature
    original_stop_log_prob = stop_log_prob.index_select(0, rows)
    stop_pick = gumbel_stop_or_edge(
        stop_logits=sampling_stop_logits,
        edge_logits=sampling_edge_logits,
        edge_row_ids=local_edge_row_ids,
        num_rows=int(rows.numel()),
    )
    stop_mask = stop_pick

    stop_rows = rows[stop_mask]
    selected_stop_log_prob = original_stop_log_prob[stop_mask]

    continue_rows = (~stop_mask).nonzero(as_tuple=False).flatten()
    if continue_rows.numel() == 0:
        return SampledFlatAction(
            stop_rows=stop_rows,
            stop_log_prob=selected_stop_log_prob,
            expand_rows=rows.new_empty((0,)),
            edge_ids=edge_ids.new_empty((0,)),
            expand_log_prob=original_edge_log_prob.new_empty((0,)),
        )

    picked_edges = segment_gumbel_argmax(
        values=sampling_edge_logits,
        row_ids=local_edge_row_ids,
        num_rows=int(rows.numel()),
    )

    expand_rows = rows[continue_rows]
    chosen_positions = picked_edges.index_select(0, continue_rows)
    expand_edge_ids = edge_ids.index_select(0, chosen_positions)
    expand_log_prob = original_edge_log_prob.index_select(0, chosen_positions)

    return SampledFlatAction(
        stop_rows=stop_rows,
        stop_log_prob=selected_stop_log_prob,
        expand_rows=expand_rows,
        edge_ids=expand_edge_ids,
        expand_log_prob=expand_log_prob,
    )


def rows_with_frontier(
    *,
    row_ids: torch.Tensor,
    num_rows: int,
    device: torch.device,
) -> torch.Tensor:
    out = torch.zeros(
        int(num_rows),
        dtype=torch.bool,
        device=device,
    )

    if row_ids.numel() > 0:
        out.index_fill_(0, row_ids, True)

    return out


def remap_rows(
    *,
    row_ids: torch.Tensor,
    rows: torch.Tensor,
    num_rows: int,
) -> torch.Tensor:
    mapping = torch.empty(
        int(num_rows),
        dtype=torch.long,
        device=rows.device,
    )

    mapping.index_copy_(
        0,
        rows,
        torch.arange(
            rows.numel(),
            dtype=torch.long,
            device=rows.device,
        ),
    )

    return mapping.index_select(0, row_ids)


def gumbel_stop_or_edge(
    *,
    stop_logits: torch.Tensor,
    edge_logits: torch.Tensor,
    edge_row_ids: torch.Tensor,
    num_rows: int,
) -> torch.Tensor:
    stop_noise = -torch.empty_like(stop_logits).exponential_().log()
    stop_score = stop_logits + stop_noise

    edge_noise = -torch.empty_like(edge_logits).exponential_().log()
    best_edge_score = torch.full(
        (int(num_rows),),
        -torch.inf,
        dtype=edge_logits.dtype,
        device=edge_logits.device,
    )
    best_edge_score.scatter_reduce_(
        0,
        edge_row_ids,
        edge_logits + edge_noise,
        reduce="amax",
        include_self=True,
    )

    return stop_score.ge(best_edge_score)


def segment_gumbel_argmax(
    *,
    values: torch.Tensor,
    row_ids: torch.Tensor,
    num_rows: int,
) -> torch.Tensor:
    noise = -torch.empty_like(values).exponential_().log()

    return segment_argmax(
        values=values + noise,
        row_ids=row_ids,
        num_rows=num_rows,
    )


def segment_argmax(
    *,
    values: torch.Tensor,
    row_ids: torch.Tensor,
    num_rows: int,
) -> torch.Tensor:
    maxima = torch.full(
        (int(num_rows),),
        -torch.inf,
        dtype=values.dtype,
        device=values.device,
    )

    maxima.scatter_reduce_(
        0,
        row_ids,
        values,
        reduce="amax",
        include_self=True,
    )

    is_max = values.eq(maxima.index_select(0, row_ids))

    positions = torch.arange(
        values.numel(),
        dtype=torch.long,
        device=values.device,
    )

    sentinel = torch.full_like(
        positions,
        values.numel(),
    )

    candidates = torch.where(
        is_max,
        positions,
        sentinel,
    )

    out = torch.full(
        (int(num_rows),),
        values.numel(),
        dtype=torch.long,
        device=values.device,
    )

    out.scatter_reduce_(
        0,
        row_ids,
        candidates,
        reduce="amin",
        include_self=True,
    )

    return out


def rollout_float(x: torch.Tensor) -> torch.Tensor:
    return x.to(dtype=ROLLOUT_LOG_PROB_DTYPE)


def cat_long(parts: list[torch.Tensor], *, device: torch.device) -> torch.Tensor:
    if not parts:
        return torch.empty(0, dtype=torch.long, device=device)
    return torch.cat(parts, dim=0).to(device=device, dtype=torch.long)


def cat_bool(parts: list[torch.Tensor], *, device: torch.device) -> torch.Tensor:
    if not parts:
        return torch.empty(0, dtype=torch.bool, device=device)
    return torch.cat(parts, dim=0).to(device=device, dtype=torch.bool)


def cat_float(
    parts: list[torch.Tensor],
    *,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    if not parts:
        return torch.empty(0, dtype=dtype, device=device)
    return torch.cat(parts, dim=0).to(device=device, dtype=dtype)


__all__ = [
    "Action",
    "ROLLOUT_LOG_PROB_DTYPE",
    "sample_action",
]
