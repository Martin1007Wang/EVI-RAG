from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

import torch

from src.data.schema import RetrievalBatch
from src.weaver.context import GraphContext
from src.weaver.rollout.result import RolloutResult
from src.weaver.state import State
from src.weaver.transitions import TransitionBatch


@dataclass(frozen=True, slots=True)
class ReplayTrajectory:
    """
    Synthetic successful trajectory used by replay.

    edge_ids is an ordered anchor-to-answer path. The terminal state after the
    final edge is the positive replay state.
    """

    graph_id: int
    edge_ids: tuple[int, ...]

    @property
    def is_empty(self) -> bool:
        return len(self.edge_ids) == 0


@dataclass(frozen=True, slots=True)
class ReplayBatch:
    transitions: TransitionBatch
    trajectories: tuple[ReplayTrajectory, ...] = ()

    @property
    def num_transitions(self) -> int:
        return int(self.transitions.num_transitions)

    @property
    def num_trajectories(self) -> int:
        return len(self.trajectories)

    @property
    def num_terminal_transitions(self) -> int:
        return int(self.transitions.is_terminal.sum().item())

    @property
    def device(self) -> torch.device:
        return self.transitions.device


@dataclass(frozen=True, slots=True)
class ReplaySampleBudget:
    policy_rollout: int
    replay_expand: int

    @property
    def total(self) -> int:
        return int(self.policy_rollout + self.replay_expand)


@dataclass(frozen=True, slots=True)
class ReplayTargetView:
    """
    Target-local shortest-path slices for one reachable answer node.

    Distances are graph-local views over the preprocessed flattened supervision
    tensors already batched on RetrievalBatch. edge_counts is target-conditioned
    and positive exactly on edges lying on at least one shortest anchor-to-target
    path.
    """

    target_node_id: int
    graph_id: int
    node_start: int
    edge_start: int
    anchor_target_distance: int
    node_distances: torch.Tensor
    edge_counts: torch.Tensor

    def node_distance(self, node_id: int) -> int:
        local_node_id = int(node_id) - int(self.node_start)
        return int(self.node_distances[local_node_id].item())

    def node_distances_for(self, node_ids: torch.Tensor) -> torch.Tensor:
        local_node_ids = node_ids.to(
            device=self.node_distances.device,
            dtype=torch.long,
        ) - int(self.node_start)
        return self.node_distances.index_select(0, local_node_ids)

    def edge_counts_for(self, edge_ids: torch.Tensor) -> torch.Tensor:
        local_edge_ids = edge_ids.to(
            device=self.edge_counts.device,
            dtype=torch.long,
        ) - int(self.edge_start)
        return self.edge_counts.index_select(0, local_edge_ids)


class ReplaySource:
    """
    Replay source for synthetic positive trajectory coverage.

    Replay builds answer-reaching paths from graph anchors and turns those
    paths into terminal-aware transitions. It is deliberately trajectory-first:
    the replay budget controls how many successful paths are mixed into the
    batch, not how many edge transitions a path happens to contain.

    This class does not construct GraphContext.
    This class does not construct RolloutContext.
    This class does not touch feature banks.
    """

    def __init__(
        self,
        *,
        expand_budget: int,
    ) -> None:
        self.expand_budget = int(expand_budget)

    @torch.no_grad()
    def sample_from_rollouts(
        self,
        *,
        batch: RetrievalBatch,
        context: GraphContext,
        rollouts: Sequence[RolloutResult],
        num_trajectories: int | None = None,
        num_transitions: int | None = None,
    ) -> ReplayBatch | None:
        if num_trajectories is None:
            if num_transitions is None:
                raise TypeError("num_trajectories is required.")
            num_trajectories = int(num_transitions)
        elif num_transitions is not None:
            raise TypeError("Pass only one of num_trajectories or num_transitions.")

        num_trajectories = int(num_trajectories)

        if num_trajectories <= 0:
            return None

        trajectories = replay_trajectories(
            batch=batch,
            context=context,
            rollouts=rollouts,
            budget=self.expand_budget,
            max_trajectories=num_trajectories,
        )
        if not trajectories:
            return None

        transitions = transitions_from_trajectories(
            trajectories=trajectories,
            context=context,
            budget=self.expand_budget,
        )
        transitions = dedupe_transitions(transitions)

        if transitions.num_transitions <= 0:
            return None

        return ReplayBatch(
            transitions=transitions,
            trajectories=tuple(trajectories),
        )


OracleTransitionSource = ReplaySource


def transitions_from_rollouts(
    *,
    rollouts: Sequence[RolloutResult],
    budget: int,
    context: GraphContext,
) -> TransitionBatch | None:
    """
    Recover parent -> child transitions from sampled rollout traces.

    Each recorded expansion step gives one transition:

        parent_state --edge_id--> child_state

    The rollout trace stores selected edge ids.
    State reconstruction is deterministic because rollout only appends edges.
    """

    parts: list[TransitionBatch] = []

    trajectory_offset = 0

    for rollout in rollouts:
        graph_ids = rollout.source_graph_id.to(
            device=context.device,
            dtype=torch.long,
        ).view(-1)
        rollout_trajectory_ids = torch.arange(
            graph_ids.numel(),
            dtype=torch.long,
            device=context.device,
        ) + trajectory_offset
        trajectory_offset += graph_ids.numel()

        current = initial_state_for_graph_ids(
            context=context,
            graph_ids=graph_ids,
            budget=budget,
        )

        for step in range(int(rollout.max_steps)):
            stop_rows = (
                rollout.terminal_mask[:, step]
                .to(
                    device=context.device,
                    dtype=torch.bool,
                )
                .nonzero(as_tuple=False)
                .flatten()
            )
            expand_rows = (
                rollout.expand_mask[:, step]
                .to(
                    device=context.device,
                    dtype=torch.bool,
                )
                .nonzero(as_tuple=False)
                .flatten()
            )

            if expand_rows.numel() > 0:
                edge_ids = (
                    rollout.selected_edge_ids[:, step]
                    .to(
                        device=context.device,
                        dtype=torch.long,
                    )
                    .index_select(0, expand_rows)
                )

                parent = current.select_rows(expand_rows).clone()
                child = parent.clone()

                child.apply_edges_(
                    context=context,
                    row_ids=torch.arange(
                        parent.num_rollouts,
                        dtype=torch.long,
                        device=context.device,
                    ),
                    edge_ids=edge_ids,
                )

                child_is_terminal = torch.zeros(
                    expand_rows.numel(),
                    dtype=torch.bool,
                    device=context.device,
                )
                next_step = step + 1
                if next_step < int(rollout.max_steps):
                    child_is_terminal = rollout.terminal_mask[:, next_step].to(
                        device=context.device,
                        dtype=torch.bool,
                    ).index_select(0, expand_rows)

                parts.append(
                    TransitionBatch(
                        parent_state=parent,
                        child_state=child,
                        trajectory_ids=rollout_trajectory_ids.index_select(0, expand_rows),
                        step_ids=torch.full(
                            (expand_rows.numel(),),
                            step,
                            dtype=torch.long,
                            device=context.device,
                        ),
                        action_edge_ids=edge_ids,
                        is_terminal=child_is_terminal,
                    )
                )

                current.apply_edges_(
                    context=context,
                    row_ids=expand_rows,
                    edge_ids=edge_ids,
                )

            if stop_rows.numel() == 0:
                continue

            stop_state = current.select_rows(stop_rows).clone()

            parts.append(
                TransitionBatch(
                    parent_state=stop_state,
                    child_state=stop_state.clone(),
                    trajectory_ids=rollout_trajectory_ids.index_select(0, stop_rows),
                    step_ids=torch.full(
                        (stop_rows.numel(),),
                        step,
                        dtype=torch.long,
                        device=context.device,
                    ),
                    action_edge_ids=torch.full(
                        (stop_rows.numel(),),
                        -1,
                        dtype=torch.long,
                        device=context.device,
                    ),
                    is_terminal=torch.ones(
                        stop_rows.numel(),
                        dtype=torch.bool,
                        device=context.device,
                    ),
                )
            )

    if not parts:
        return None

    return TransitionBatch.concat(parts)


def replay_trajectories(
    *,
    batch: RetrievalBatch,
    context: GraphContext,
    budget: int,
    max_trajectories: int | None = None,
    rollouts: Sequence[RolloutResult] = (),
) -> list[ReplayTrajectory]:
    """
    Build successful replay trajectories from directed shortest paths.

    If policy rollouts are available, replay focuses on graphs that have not
    reached an answer in the current rollout set. When no rollout is available
    (for example, a replay-only schedule), every graph with a reachable target
    is eligible.
    """

    max_trajectories = None if max_trajectories is None else int(max_trajectories)
    if max_trajectories is not None and max_trajectories <= 0:
        return []

    targets = batch.reachable_target_node_ids.to(
        device=context.device,
        dtype=torch.long,
    ).view(-1)

    if targets.numel() == 0:
        return []

    target_graph = context.node_to_graph.index_select(0, targets)
    eligible_graphs = replay_graph_ids(
        targets=targets,
        target_graph=target_graph,
        context=context,
        rollouts=rollouts,
        budget=int(budget),
    )

    if not eligible_graphs:
        return []

    trajectories: list[ReplayTrajectory] = []
    target_views = build_replay_target_views(
        batch=batch,
        context=context,
        targets=targets,
        target_graph=target_graph,
    )

    for graph_id in range(int(context.num_graphs)):
        if graph_id not in eligible_graphs:
            continue

        graph_target_positions = target_graph.eq(int(graph_id)).nonzero(as_tuple=False).view(-1)
        if graph_target_positions.numel() == 0:
            continue

        for target_pos in graph_target_positions.tolist():
            path = precomputed_shortest_edge_path(
                batch=batch,
                context=context,
                target_view=target_views[int(target_pos)],
                budget=int(budget),
            )

            if not path:
                continue

            trajectories.append(
                ReplayTrajectory(
                    graph_id=int(graph_id),
                    edge_ids=tuple(int(edge_id) for edge_id in path[: int(budget)]),
                )
            )

    if max_trajectories is not None and len(trajectories) > max_trajectories:
        order = torch.randperm(
            len(trajectories),
            device=context.device,
        )[:max_trajectories].cpu()
        trajectories = [trajectories[int(i)] for i in order.tolist()]

    return trajectories


def replay_graph_ids(
    *,
    targets: torch.Tensor,
    target_graph: torch.Tensor,
    context: GraphContext,
    rollouts: Sequence[RolloutResult],
    budget: int,
) -> set[int]:
    graphs_with_targets = {int(x) for x in target_graph.tolist()}
    if not rollouts:
        return graphs_with_targets

    hit_graphs = rollout_hit_graph_ids(
        rollouts=rollouts,
        targets=targets,
        context=context,
        budget=int(budget),
    )
    return graphs_with_targets - hit_graphs


def rollout_hit_graph_ids(
    *,
    rollouts: Sequence[RolloutResult],
    targets: torch.Tensor,
    context: GraphContext,
    budget: int,
) -> set[int]:
    target_mask = torch.zeros(
        int(context.num_nodes),
        dtype=torch.bool,
        device=context.device,
    )
    if targets.numel() > 0:
        target_mask[targets.to(device=context.device, dtype=torch.long)] = True

    hit_graphs: set[int] = set()

    for rollout in rollouts:
        graph_ids = rollout.source_graph_id.to(
            device=context.device,
            dtype=torch.long,
        ).view(-1)
        if graph_ids.numel() == 0:
            continue

        state = initial_state_for_graph_ids(
            context=context,
            graph_ids=graph_ids,
            budget=int(budget),
        )

        for step in range(int(rollout.max_steps)):
            expand_rows = (
                rollout.expand_mask[:, step]
                .to(
                    device=context.device,
                    dtype=torch.bool,
                )
                .nonzero(as_tuple=False)
                .flatten()
            )

            if expand_rows.numel() == 0:
                continue

            edge_ids = (
                rollout.selected_edge_ids[:, step]
                .to(
                    device=context.device,
                    dtype=torch.long,
                )
                .index_select(0, expand_rows)
            )

            state.apply_edges_(
                context=context,
                row_ids=expand_rows,
                edge_ids=edge_ids,
            )

        has_target = (state.node_mask & target_mask.view(1, -1)).any(dim=1)
        for graph_id in graph_ids[has_target].tolist():
            hit_graphs.add(int(graph_id))

    return hit_graphs


def transitions_from_trajectories(
    *,
    trajectories: Sequence[ReplayTrajectory],
    context: GraphContext,
    budget: int,
) -> TransitionBatch:
    """
    Convert successful replay trajectories into terminal-aware transitions.
    """

    parts: list[TransitionBatch] = []

    for trajectory_id, trajectory in enumerate(trajectories):
        if trajectory.is_empty:
            continue

        current = initial_state_for_graph_ids(
            context=context,
            graph_ids=torch.tensor(
                [int(trajectory.graph_id)],
                dtype=torch.long,
                device=context.device,
            ),
            budget=int(budget),
        )

        last_step = len(trajectory.edge_ids) - 1
        for step, edge_id in enumerate(trajectory.edge_ids):
            edge_ids = torch.tensor(
                [int(edge_id)],
                dtype=torch.long,
                device=context.device,
            )

            parent = current.clone()
            child = current.clone()

            child.apply_edges_(
                context=context,
                row_ids=torch.zeros(
                    1,
                    dtype=torch.long,
                    device=context.device,
                ),
                edge_ids=edge_ids,
            )

            parts.append(
                TransitionBatch(
                    parent_state=parent,
                    child_state=child,
                    trajectory_ids=torch.tensor(
                        [trajectory_id],
                        dtype=torch.long,
                        device=context.device,
                    ),
                    step_ids=torch.tensor(
                        [step],
                        dtype=torch.long,
                        device=context.device,
                    ),
                    action_edge_ids=edge_ids,
                    is_terminal=torch.zeros(
                        1,
                        dtype=torch.bool,
                        device=context.device,
                    ),
                )
            )

            current = child

        final_state = current.clone()
        parts.append(
            TransitionBatch(
                parent_state=final_state,
                child_state=final_state.clone(),
                trajectory_ids=torch.tensor(
                    [trajectory_id],
                    dtype=torch.long,
                    device=context.device,
                ),
                step_ids=torch.tensor(
                    [len(trajectory.edge_ids)],
                    dtype=torch.long,
                    device=context.device,
                ),
                action_edge_ids=torch.full(
                    (1,),
                    -1,
                    dtype=torch.long,
                    device=context.device,
                ),
                is_terminal=torch.ones(
                    1,
                    dtype=torch.bool,
                    device=context.device,
                ),
            )
        )

    if not parts:
        empty_state = initial_state_for_graph_ids(
            context=context,
            graph_ids=torch.empty(0, dtype=torch.long, device=context.device),
            budget=int(budget),
        )
        return TransitionBatch(
            parent_state=empty_state,
            child_state=empty_state,
            trajectory_ids=torch.empty(0, dtype=torch.long, device=context.device),
            step_ids=torch.empty(0, dtype=torch.long, device=context.device),
            action_edge_ids=torch.empty(0, dtype=torch.long, device=context.device),
            is_terminal=torch.empty(0, dtype=torch.bool, device=context.device),
        )

    return TransitionBatch.concat(parts)


def oracle_prefix_transitions(
    *,
    batch: RetrievalBatch,
    context: GraphContext,
    budget: int,
) -> TransitionBatch | None:
    """
    Compatibility wrapper for older callers.

    Replay is now trajectory-first, and the final transition in each synthetic
    path is terminal. New code should use replay_trajectories plus
    transitions_from_trajectories.
    """

    trajectories = replay_trajectories(
        batch=batch,
        context=context,
        budget=int(budget),
    )
    if not trajectories:
        return None

    return transitions_from_trajectories(
        trajectories=trajectories,
        context=context,
        budget=int(budget),
    )


def initial_state_for_graph_ids(
    *,
    context: GraphContext,
    graph_ids: torch.Tensor,
    budget: int,
) -> State:
    """
    Build one initial rollout state per graph id.

    State.initial(context, rollouts_per_graph=1) has row id == graph id.
    select_rows(graph_ids) also supports repeated graph ids.
    """

    base = State.initial(
        context=context,
        budget=int(budget),
        rollouts_per_graph=1,
    )

    return base.select_rows(
        graph_ids.to(
            device=context.device,
            dtype=torch.long,
        ).view(-1)
    )


def dedupe_transitions(batch: TransitionBatch) -> TransitionBatch:
    """
    Remove duplicate parent/action transitions.

    Key:
        graph id
        selected parent edge set
        action edge id
    """

    edge_masks = batch.parent_state.edge_mask.detach().cpu()
    graphs = batch.parent_state.row_to_graph.detach().cpu()
    action_edge_ids = batch.action_edge_ids.detach().cpu()

    terminal = batch.is_terminal.detach().cpu()
    seen: dict[tuple[int, tuple[int, ...], int], int] = {}
    keep: list[int] = []

    for row in range(int(batch.num_transitions)):
        selected_edges = tuple(edge_masks[row].nonzero(as_tuple=False).view(-1).tolist())

        key = (
            int(graphs[row]),
            selected_edges,
            int(action_edge_ids[row]),
        )

        if key in seen:
            keep_index = seen[key]
            if bool(terminal[row]) and not bool(terminal[keep[keep_index]]):
                keep[keep_index] = row
            continue

        seen[key] = len(keep)
        keep.append(row)

    rows = torch.tensor(
        keep,
        dtype=torch.long,
        device=batch.device,
    )

    return batch.select_rows(rows)


def build_replay_target_views(
    *,
    batch: RetrievalBatch,
    context: GraphContext,
    targets: torch.Tensor,
    target_graph: torch.Tensor,
) -> tuple[ReplayTargetView, ...]:
    """
    Build per-target graph-local views over batched shortest-path supervision.
    """
    if targets.ndim != 1:
        raise ValueError(f"targets must have shape [T], got {tuple(targets.shape)}.")
    if target_graph.shape != targets.shape:
        raise ValueError(
            "target_graph must have the same shape as targets: "
            f"{tuple(target_graph.shape)} != {tuple(targets.shape)}."
        )

    device = context.device
    num_graphs = int(context.num_graphs)
    node_ptr = batch.ptr.to(device=device, dtype=torch.long)
    edge_ptr = edge_ptr_from_batch(batch=batch).to(device=device, dtype=torch.long)
    node_counts = torch.diff(node_ptr)
    edge_counts = torch.diff(edge_ptr)
    target_counts = torch.bincount(
        target_graph.to(device=device, dtype=torch.long),
        minlength=num_graphs,
    ).to(device=device, dtype=torch.long)
    local_target_positions = torch.empty_like(
        target_graph,
        dtype=torch.long,
        device=device,
    )

    for graph_id in range(num_graphs):
        positions = target_graph.eq(graph_id).nonzero(as_tuple=False).view(-1)
        if positions.numel() == 0:
            continue
        local_target_positions[positions] = torch.arange(
            positions.numel(),
            dtype=torch.long,
            device=device,
        )

    node_base_offsets = torch.cat(
        [
            node_counts.new_zeros(1),
            (target_counts * node_counts).cumsum(dim=0)[:-1],
        ],
        dim=0,
    )
    edge_base_offsets = torch.cat(
        [
            edge_counts.new_zeros(1),
            (target_counts * edge_counts).cumsum(dim=0)[:-1],
        ],
        dim=0,
    )
    node_distance_flat = batch.node_target_distances_flat.to(
        device=device,
        dtype=torch.long,
    )
    edge_count_flat = batch.node_target_shortest_path_edge_count_flat.to(
        device=device,
        dtype=torch.float32,
    )
    anchor_forward = batch.anchor_node_forward_distances_flat.to(
        device=device,
        dtype=torch.long,
    )

    views: list[ReplayTargetView] = []
    for target_pos, target in enumerate(targets.tolist()):
        graph_id = int(target_graph[target_pos].item())
        num_nodes = int(node_counts[graph_id].item())
        num_edges = int(edge_counts[graph_id].item())
        local_target_pos = int(local_target_positions[target_pos].item())
        node_offset = int(node_base_offsets[graph_id].item()) + local_target_pos * num_nodes
        edge_offset = int(edge_base_offsets[graph_id].item()) + local_target_pos * num_edges

        views.append(
            ReplayTargetView(
                target_node_id=int(target),
                graph_id=graph_id,
                node_start=int(node_ptr[graph_id].item()),
                edge_start=int(edge_ptr[graph_id].item()),
                anchor_target_distance=int(anchor_forward[int(target)].item()),
                node_distances=node_distance_flat.narrow(0, node_offset, num_nodes),
                edge_counts=edge_count_flat.narrow(0, edge_offset, num_edges),
            )
        )

    return tuple(views)


def precomputed_shortest_edge_path(
    *,
    batch: RetrievalBatch,
    context: GraphContext,
    target_view: ReplayTargetView,
    budget: int,
) -> list[int]:
    """
    Recover one canonical shortest anchor-to-target path from precomputed labels.

    Tie-breaks are fully label-driven:
    - choose the smallest anchor id among nearest anchors
    - at each step choose the valid shortest-path edge with largest
      target-conditioned shortest-path count, then smallest edge id
    """
    distance = int(target_view.anchor_target_distance)
    if distance <= 0 or distance > int(budget):
        return []

    anchors = graph_anchor_ids(
        batch=batch,
        graph_id=int(target_view.graph_id),
        device=context.device,
    )
    if anchors.numel() == 0:
        return []

    anchor_distances = target_view.node_distances_for(anchors)
    nearest_anchors = anchors[anchor_distances.eq(distance)]
    if nearest_anchors.numel() == 0:
        return []

    current = int(nearest_anchors.min().item())
    target = int(target_view.target_node_id)
    path: list[int] = []

    for _ in range(distance):
        if current == target:
            break

        current_distance = target_view.node_distance(current)
        if current_distance <= 0:
            return []

        edge_ids = outgoing_edges(
            context=context,
            node=current,
        )
        if edge_ids.numel() == 0:
            return []

        dst_nodes = context.edge_index[1].index_select(0, edge_ids)
        dst_distances = target_view.node_distances_for(dst_nodes)
        edge_counts = target_view.edge_counts_for(edge_ids)
        valid = edge_counts.gt(0) & dst_distances.eq(current_distance - 1)
        if not bool(valid.any()):
            return []

        chosen_edge = choose_canonical_replay_edge(
            edge_ids=edge_ids[valid],
            edge_counts=edge_counts[valid],
        )
        path.append(int(chosen_edge))
        current = int(context.edge_index[1, chosen_edge].item())

    if current != target:
        return []

    return path


def graph_anchor_ids(
    *,
    batch: RetrievalBatch,
    graph_id: int,
    device: torch.device,
) -> torch.Tensor:
    anchors = batch.anchor_node_ids.to(
        device=device,
        dtype=torch.long,
    ).view(-1)
    if anchors.numel() == 0:
        return anchors

    node_ptr = batch.ptr.to(device=device, dtype=torch.long)
    start = node_ptr[int(graph_id)]
    end = node_ptr[int(graph_id) + 1]
    return anchors[(anchors >= start) & (anchors < end)]


def choose_canonical_replay_edge(
    *,
    edge_ids: torch.Tensor,
    edge_counts: torch.Tensor,
) -> int:
    if edge_ids.numel() == 0:
        raise ValueError("edge_ids must be non-empty.")
    if edge_counts.shape != edge_ids.shape:
        raise ValueError(
            "edge_counts must have the same shape as edge_ids: "
            f"{tuple(edge_counts.shape)} != {tuple(edge_ids.shape)}."
        )

    max_count = edge_counts.max()
    best_edges = edge_ids[edge_counts.eq(max_count)]
    return int(best_edges.min().item())


def edge_ptr_from_batch(
    *,
    batch: RetrievalBatch,
) -> torch.Tensor:
    edge_batch = batch.edge_batch.to(dtype=torch.long)
    edge_counts = torch.bincount(
        edge_batch,
        minlength=int(batch.num_graphs_total),
    )
    return torch.cat(
        [
            edge_counts.new_zeros(1),
            edge_counts.cumsum(dim=0),
        ],
        dim=0,
    )


def outgoing_edges(
    *,
    context: GraphContext,
    node: int,
) -> torch.Tensor:
    start = context.outgoing_ptr[int(node)]
    end = context.outgoing_ptr[int(node) + 1]

    return context.edge_ids_by_src[start:end]


__all__ = [
    "ReplayBatch",
    "ReplaySampleBudget",
    "ReplaySource",
    "OracleTransitionSource",
    "ReplayTrajectory",
    "dedupe_transitions",
    "initial_state_for_graph_ids",
    "oracle_prefix_transitions",
    "replay_graph_ids",
    "replay_trajectories",
    "rollout_hit_graph_ids",
    "transitions_from_trajectories",
    "transitions_from_rollouts",
]
