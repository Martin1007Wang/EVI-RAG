from __future__ import annotations

from dataclasses import dataclass, field

import torch

from src.weaver.rollout.action import Action, ROLLOUT_LOG_PROB_DTYPE

NO_EDGE = -1
NO_STEP = -1


@dataclass(slots=True)
class RolloutTrace:
    """
    Trajectory recorder for fused vectorized rollout.

    It records what happened.
    It does not define action semantics.
    It does not validate rollout control flow.
    It does not update State.

    Shapes:
        selected_edge_ids: [R, T]
        expand_mask:      [R, T]
        stop_mask:        [R, T]
    """

    R: int
    T: int
    device: torch.device
    dtype: torch.dtype = ROLLOUT_LOG_PROB_DTYPE

    selected_edge_ids: torch.Tensor = field(init=False)
    action_log_prob: torch.Tensor = field(init=False)
    expand_mask: torch.Tensor = field(init=False)
    stop_mask: torch.Tensor = field(init=False)

    stop_log_prob: torch.Tensor = field(init=False)
    stop_step: torch.Tensor = field(init=False)
    forced_stop: torch.Tensor = field(init=False)
    is_stopped: torch.Tensor = field(init=False)
    traj_len: torch.Tensor = field(init=False)

    def __post_init__(self) -> None:
        self.R = int(self.R)
        self.T = int(self.T)
        if not self.dtype.is_floating_point:
            raise ValueError(f"RolloutTrace dtype must be floating point, got {self.dtype}.")

        shape = (self.R, self.T)

        self.selected_edge_ids = torch.full(
            shape,
            NO_EDGE,
            dtype=torch.long,
            device=self.device,
        )

        self.action_log_prob = torch.zeros(
            shape,
            dtype=self.dtype,
            device=self.device,
        )

        self.expand_mask = torch.zeros(
            shape,
            dtype=torch.bool,
            device=self.device,
        )

        self.stop_mask = torch.zeros(
            shape,
            dtype=torch.bool,
            device=self.device,
        )

        self.stop_log_prob = torch.zeros(
            self.R,
            dtype=self.dtype,
            device=self.device,
        )

        self.stop_step = torch.full(
            (self.R,),
            NO_STEP,
            dtype=torch.long,
            device=self.device,
        )

        self.forced_stop = torch.zeros(
            self.R,
            dtype=torch.bool,
            device=self.device,
        )

        self.is_stopped = torch.zeros(
            self.R,
            dtype=torch.bool,
            device=self.device,
        )

        self.traj_len = torch.zeros(
            self.R,
            dtype=torch.long,
            device=self.device,
        )

    @property
    def selected_edges(self) -> torch.Tensor:
        return self.selected_edge_ids

    @property
    def valid_mask(self) -> torch.Tensor:
        return self.expand_mask | self.stop_mask

    @property
    def terminal_mask(self) -> torch.Tensor:
        return self.stop_mask

    @property
    def forced_terminal_mask(self) -> torch.Tensor:
        out = torch.zeros_like(self.stop_mask)

        stopped_rows = self.is_stopped.nonzero(as_tuple=False).flatten()
        if stopped_rows.numel() == 0:
            return out

        steps = self.stop_step.index_select(0, stopped_rows)
        out[stopped_rows, steps] = self.forced_stop.index_select(0, stopped_rows)

        return out

    @property
    def terminal_log_prob(self) -> torch.Tensor:
        return self.stop_log_prob

    @property
    def terminal_step(self) -> torch.Tensor:
        return self.stop_step

    @property
    def action_type(self) -> torch.Tensor:
        out = torch.zeros_like(self.selected_edge_ids)
        out[self.expand_mask] = 1
        out[self.stop_mask] = 2
        return out

    def write_action(
        self,
        *,
        t: int,
        active_rows: torch.Tensor,
        action: Action,
    ) -> None:
        """
        Record one vectorized rollout step.

        action row ids are local to active_rows.
        trace row ids are global fused-rollout rows.
        """

        step = int(t)

        if action.expand_rows.numel() > 0:
            rows = active_rows.index_select(0, action.expand_rows)

            self.expand_mask[rows, step] = True
            self.selected_edge_ids[rows, step] = action.edge_ids
            self.action_log_prob[rows, step] = self.record_float(
                action.expand_log_prob,
            )

        if action.stop_rows.numel() > 0:
            rows = active_rows.index_select(0, action.stop_rows)

            self.stop_mask[rows, step] = True
            stop_log_prob = self.record_float(action.stop_log_prob)
            self.stop_log_prob[rows] = stop_log_prob
            self.action_log_prob[rows, step] = stop_log_prob
            self.stop_step[rows] = step
            self.forced_stop[rows] = action.forced_stop
            self.is_stopped[rows] = True
            self.traj_len[rows] = step + 1

    def record_float(self, value: torch.Tensor) -> torch.Tensor:
        return value.to(
            device=self.device,
            dtype=self.dtype,
        )


__all__ = [
    "NO_EDGE",
    "NO_STEP",
    "RolloutTrace",
]
