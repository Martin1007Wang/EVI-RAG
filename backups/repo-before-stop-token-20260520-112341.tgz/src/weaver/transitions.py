from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import torch

from src.weaver.state import State

TRANSITION_SOURCE_UNKNOWN = -1
TRANSITION_SOURCE_POLICY = 0
TRANSITION_SOURCE_REPLAY = 1


@dataclass(frozen=True, slots=True)
class TransitionBatch:
    parent_state: State
    child_state: State
    action_edge_ids: torch.Tensor
    trajectory_ids: torch.Tensor | None = None
    step_ids: torch.Tensor | None = None
    is_terminal: torch.Tensor | None = None
    source_ids: torch.Tensor | None = None

    def __post_init__(self) -> None:
        action_edge_ids = self.action_edge_ids.view(-1)
        num_transitions = action_edge_ids.numel()
        device = action_edge_ids.device

        if self.trajectory_ids is None:
            trajectory_ids = torch.arange(
                num_transitions,
                dtype=torch.long,
                device=device,
            )
        else:
            trajectory_ids = self.trajectory_ids.to(
                device=device,
                dtype=torch.long,
            ).view(-1)

        if self.step_ids is None:
            step_ids = torch.zeros(
                num_transitions,
                dtype=torch.long,
                device=device,
            )
        else:
            step_ids = self.step_ids.to(
                device=device,
                dtype=torch.long,
            ).view(-1)

        if trajectory_ids.numel() != num_transitions:
            raise ValueError(
                "trajectory_ids must have one value per transition: "
                f"{trajectory_ids.numel()} != {num_transitions}."
            )
        if step_ids.numel() != num_transitions:
            raise ValueError(
                "step_ids must have one value per transition: "
                f"{step_ids.numel()} != {num_transitions}."
            )

        object.__setattr__(self, "trajectory_ids", trajectory_ids)
        object.__setattr__(self, "step_ids", step_ids)

        if self.source_ids is None:
            object.__setattr__(
                self,
                "source_ids",
                torch.full(
                    (num_transitions,),
                    TRANSITION_SOURCE_UNKNOWN,
                    dtype=torch.long,
                    device=device,
                ),
            )
        else:
            source_ids = self.source_ids.to(
                device=device,
                dtype=torch.long,
            ).view(-1)
            if source_ids.numel() != num_transitions:
                raise ValueError(
                    "source_ids must have one value per transition: "
                    f"{source_ids.numel()} != {num_transitions}."
                )
            object.__setattr__(self, "source_ids", source_ids)

        if self.is_terminal is None:
            object.__setattr__(
                self,
                "is_terminal",
                torch.zeros(
                    num_transitions,
                    dtype=torch.bool,
                    device=action_edge_ids.device,
                ),
            )
            return

        is_terminal = self.is_terminal.to(
            device=action_edge_ids.device,
            dtype=torch.bool,
        ).view(-1)
        if is_terminal.numel() != action_edge_ids.numel():
            raise ValueError(
                "is_terminal must have one value per transition: "
                f"{is_terminal.numel()} != {action_edge_ids.numel()}."
            )

        object.__setattr__(self, "is_terminal", is_terminal)

    @property
    def num_transitions(self) -> int:
        return int(self.action_edge_ids.numel())

    @property
    def device(self) -> torch.device:
        return self.action_edge_ids.device

    @classmethod
    def concat(
        cls,
        batches: Sequence[TransitionBatch],
    ) -> TransitionBatch:
        if not batches:
            raise ValueError("Cannot concatenate an empty transition sequence.")
        if len(batches) == 1:
            return batches[0]
        return cls(
            parent_state=State.concat([batch.parent_state for batch in batches]),
            child_state=State.concat([batch.child_state for batch in batches]),
            trajectory_ids=torch.cat(
                [batch.trajectory_ids.view(-1) for batch in batches],
                dim=0,
            ),
            step_ids=torch.cat(
                [batch.step_ids.view(-1) for batch in batches],
                dim=0,
            ),
            action_edge_ids=torch.cat(
                [batch.action_edge_ids.view(-1) for batch in batches],
                dim=0,
            ),
            is_terminal=torch.cat(
                [batch.is_terminal.view(-1) for batch in batches],
                dim=0,
            ),
            source_ids=torch.cat(
                [batch.source_ids.view(-1) for batch in batches],
                dim=0,
            ),
        )

    @classmethod
    def concat_reindex_trajectories(
        cls,
        batches: Sequence[TransitionBatch],
    ) -> TransitionBatch:
        reindexed: list[TransitionBatch] = []
        trajectory_offset = 0

        for batch in batches:
            trajectory_ids = reindex_trajectory_ids(batch.trajectory_ids)
            if trajectory_ids.numel() > 0:
                num_trajectories = int(trajectory_ids.max().item()) + 1
                trajectory_ids = trajectory_ids + trajectory_offset
                trajectory_offset += num_trajectories

            reindexed.append(
                cls(
                    parent_state=batch.parent_state,
                    child_state=batch.child_state,
                    trajectory_ids=trajectory_ids,
                    step_ids=batch.step_ids,
                    action_edge_ids=batch.action_edge_ids,
                    is_terminal=batch.is_terminal,
                    source_ids=batch.source_ids,
                )
            )

        return cls.concat(reindexed)

    def select_rows(
        self,
        rows: torch.Tensor,
    ) -> TransitionBatch:
        rows = rows.to(device=self.device, dtype=torch.long).view(-1)
        return TransitionBatch(
            parent_state=self.parent_state.select_rows(rows),
            child_state=self.child_state.select_rows(rows),
            trajectory_ids=self.trajectory_ids.index_select(0, rows),
            step_ids=self.step_ids.index_select(0, rows),
            action_edge_ids=self.action_edge_ids.index_select(0, rows),
            is_terminal=self.is_terminal.index_select(0, rows),
            source_ids=self.source_ids.index_select(0, rows),
        )

    def with_source_id(
        self,
        source_id: int,
    ) -> TransitionBatch:
        return TransitionBatch(
            parent_state=self.parent_state,
            child_state=self.child_state,
            trajectory_ids=self.trajectory_ids,
            step_ids=self.step_ids,
            action_edge_ids=self.action_edge_ids,
            is_terminal=self.is_terminal,
            source_ids=torch.full(
                (self.num_transitions,),
                int(source_id),
                dtype=torch.long,
                device=self.device,
            ),
        )


def reindex_trajectory_ids(
    trajectory_ids: torch.Tensor,
) -> torch.Tensor:
    trajectory_ids = trajectory_ids.view(-1)
    if trajectory_ids.numel() == 0:
        return trajectory_ids

    unique_ids, inverse = torch.unique(
        trajectory_ids,
        sorted=True,
        return_inverse=True,
    )
    del unique_ids
    return inverse


__all__ = [
    "TRANSITION_SOURCE_POLICY",
    "TRANSITION_SOURCE_REPLAY",
    "TRANSITION_SOURCE_UNKNOWN",
    "TransitionBatch",
]
