from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from src.data.schema import RetrievalBatch
from src.weaver.context import GraphContext, RewardContext
from src.weaver.state import State


@dataclass(frozen=True, slots=True)
class RewardOutput:
    """
    Terminal reward values for a batch of states.

    valid_mask marks rows whose graph has at least one reachable target.
    It is intentionally not applied inside Reward. The loss must decide
    whether invalid rows contribute.
    """

    log_reward: torch.Tensor
    raw_log_reward: torch.Tensor

    answer_recall: torch.Tensor
    answer_utility: torch.Tensor
    edge_penalty: torch.Tensor
    fail_penalty: torch.Tensor

    selected_edge_count: torch.Tensor
    supported_count: torch.Tensor
    target_count: torch.Tensor
    valid_mask: torch.Tensor

    @property
    def no_answer(self) -> torch.Tensor:
        return self.supported_count.eq(0)


class Reward(nn.Module):
    """
    Terminal-only reward for evidence-subgraph GFlowNet training.

    For a state z = (S_V, S_E):

        supported_count(z) = |S_V ∩ Y|
        recall(z)          = supported_count(z) / |Y|

        raw_log_R(z)
            = log(epsilon + answer_utility_weight * recall(z))
              - edge_cost * |S_E|
              - fail_cost * 1[supported_count(z) = 0]

        log_R(z) = raw_log_R(z) / log_reward_scale

    Contract:
    - Reward is terminal-only.
    - Reward does not define per-edge reward.
    - Reward does not use semantic/model-space features.
    - Reward does not use potential shaping.
    - Reward does not repair caller-provided tensor dtype/device/shape.
    - invalid rows are reported through valid_mask, not silently removed.
    """

    def __init__(
        self,
        *,
        epsilon: float = 1.0e-6,
        answer_utility_weight: float = 1.0,
        edge_cost: float = 0.05,
        fail_cost: float = 1.0,
        log_reward_scale: float = 5.0,
    ) -> None:
        super().__init__()

        if epsilon <= 0.0:
            raise ValueError(f"epsilon must be positive, got {epsilon}.")
        if answer_utility_weight <= 0.0:
            raise ValueError(
                f"answer_utility_weight must be positive, got {answer_utility_weight}."
            )
        if edge_cost < 0.0:
            raise ValueError(f"edge_cost must be non-negative, got {edge_cost}.")
        if fail_cost < 0.0:
            raise ValueError(f"fail_cost must be non-negative, got {fail_cost}.")
        if log_reward_scale <= 0.0:
            raise ValueError(
                f"log_reward_scale must be positive, got {log_reward_scale}."
            )

        self.epsilon = float(epsilon)
        self.answer_utility_weight = float(answer_utility_weight)
        self.edge_cost = float(edge_cost)
        self.fail_cost = float(fail_cost)
        self.log_reward_scale = float(log_reward_scale)

    @torch.no_grad()
    def prepare_context(
        self,
        batch: RetrievalBatch,
        *,
        expand_budget: int,
    ) -> RewardContext:
        graph_context = GraphContext.from_batch(batch)
        return RewardContext.from_batch(
            batch=batch,
            graph_context=graph_context,
            expand_budget=expand_budget,
        )

    @torch.no_grad()
    def forward(
        self,
        *,
        state: State,
        context: RewardContext,
    ) -> RewardOutput:
        row_to_graph = state.row_to_graph

        target_count = context.target_count_by_graph.index_select(
            0,
            row_to_graph,
        )
        valid_mask = target_count.gt(0)

        supported_count = (state.node_mask & context.target_mask).sum(dim=1)
        answer_recall = supported_count / target_count.clamp_min(1)

        # This assumes state.edge_mask contains only policy-selected evidence
        # edges. If State later includes root/anchor edges, expose an explicit
        # expansion_edge_count on State and use it here.
        selected_edge_count = state.edge_mask.sum(dim=1)

        answer_utility = self.answer_utility_weight * answer_recall
        edge_penalty = self.edge_cost * selected_edge_count
        fail_penalty = self.fail_cost * supported_count.eq(0)

        raw_log_reward = (
            torch.log(self.epsilon + answer_utility) - edge_penalty - fail_penalty
        )
        log_reward = raw_log_reward / self.log_reward_scale

        return RewardOutput(
            log_reward=log_reward,
            raw_log_reward=raw_log_reward,
            answer_recall=answer_recall,
            answer_utility=answer_utility,
            edge_penalty=edge_penalty,
            fail_penalty=fail_penalty,
            selected_edge_count=selected_edge_count,
            supported_count=supported_count,
            target_count=target_count,
            valid_mask=valid_mask,
        )


__all__ = [
    "Reward",
    "RewardOutput",
]
