from __future__ import annotations

from dataclasses import dataclass

import torch

from src.data.schema import RetrievalBatch


@dataclass(frozen=True, slots=True)
class GraphContext:
    """
    Static label-free graph context.

    This is the only graph object needed by rollout, policy evaluation,
    frontier construction, and inference.

    It intentionally excludes target labels and oracle supervision.
    """

    edge_index: torch.Tensor
    node_to_graph: torch.Tensor
    edge_to_graph: torch.Tensor
    anchor_mask: torch.Tensor

    outgoing_ptr: torch.Tensor
    edge_ids_by_src: torch.Tensor

    num_nodes: int
    num_edges: int
    num_graphs: int

    @classmethod
    def from_batch(
        cls,
        batch: RetrievalBatch,
    ) -> GraphContext:
        edge_index = batch.edge_index
        node_to_graph = batch.batch.view(-1)

        edge_to_graph = node_to_graph.index_select(
            0,
            edge_index[0],
        )

        anchor_mask = torch.zeros(
            int(batch.num_nodes_total),
            dtype=torch.bool,
            device=edge_index.device,
        )

        anchors = batch.anchor_node_ids.view(-1)
        if anchors.numel() > 0:
            anchor_mask[anchors] = True

        outgoing_ptr, edge_ids_by_src = build_outgoing_index(
            edge_index=edge_index,
            num_nodes=int(batch.num_nodes_total),
        )

        return cls(
            edge_index=edge_index,
            node_to_graph=node_to_graph,
            edge_to_graph=edge_to_graph,
            anchor_mask=anchor_mask,
            outgoing_ptr=outgoing_ptr,
            edge_ids_by_src=edge_ids_by_src,
            num_nodes=int(batch.num_nodes_total),
            num_edges=int(batch.num_edges_total),
            num_graphs=int(batch.num_graphs_total),
        )

    @property
    def device(self) -> torch.device:
        return self.edge_index.device


@dataclass(frozen=True, slots=True)
class RewardContext:
    """
    Target-bearing supervision context.

    Used only for reward / evaluation.
    Never required by label-free rollout or inference.
    """

    target_mask: torch.Tensor
    target_count_by_graph: torch.Tensor
    edge_index: torch.Tensor
    node_to_graph: torch.Tensor
    anchor_mask: torch.Tensor
    expand_budget: int
    reachable_target_node_ids: torch.Tensor
    target_graph: torch.Tensor
    node_ptr: torch.Tensor
    edge_ptr: torch.Tensor
    node_label_offset_by_graph: torch.Tensor
    edge_label_offset_by_graph: torch.Tensor
    node_target_distances_flat: torch.Tensor
    node_target_shortest_path_edge_count_flat: torch.Tensor
    anchor_node_forward_distances_flat: torch.Tensor

    @classmethod
    def from_batch(
        cls,
        *,
        batch: RetrievalBatch,
        graph_context: GraphContext,
        expand_budget: int,
    ) -> RewardContext:
        target_mask = torch.zeros(
            int(graph_context.num_nodes),
            dtype=torch.bool,
            device=graph_context.device,
        )

        targets = batch.reachable_target_node_ids.to(
            device=graph_context.device,
            dtype=torch.long,
        ).view(-1)

        if targets.numel() > 0:
            target_mask[targets] = True

        target_graph = graph_context.node_to_graph.index_select(
            0,
            targets,
        )

        target_count_by_graph = torch.bincount(
            target_graph,
            minlength=int(graph_context.num_graphs),
        ).to(
            device=graph_context.device,
            dtype=torch.long,
        )
        node_ptr = batch.ptr.to(
            device=graph_context.device,
            dtype=torch.long,
        )
        edge_ptr = edge_ptr_from_batch(
            batch=batch,
            graph_context=graph_context,
        )
        node_count_by_graph = torch.diff(node_ptr)
        edge_count_by_graph = torch.diff(edge_ptr)
        node_label_offset_by_graph = torch.cat(
            [
                target_count_by_graph.new_zeros(1),
                (target_count_by_graph * node_count_by_graph).cumsum(dim=0)[:-1],
            ],
            dim=0,
        )
        edge_label_offset_by_graph = torch.cat(
            [
                target_count_by_graph.new_zeros(1),
                (target_count_by_graph * edge_count_by_graph).cumsum(dim=0)[:-1],
            ],
            dim=0,
        )

        return cls(
            target_mask=target_mask,
            target_count_by_graph=target_count_by_graph,
            edge_index=graph_context.edge_index,
            node_to_graph=graph_context.node_to_graph,
            anchor_mask=graph_context.anchor_mask,
            expand_budget=int(expand_budget),
            reachable_target_node_ids=targets,
            target_graph=target_graph,
            node_ptr=node_ptr,
            edge_ptr=edge_ptr,
            node_label_offset_by_graph=node_label_offset_by_graph,
            edge_label_offset_by_graph=edge_label_offset_by_graph,
            node_target_distances_flat=batch.node_target_distances_flat.to(
                device=graph_context.device,
                dtype=torch.long,
            ),
            node_target_shortest_path_edge_count_flat=batch.node_target_shortest_path_edge_count_flat.to(
                device=graph_context.device,
                dtype=torch.float32,
            ),
            anchor_node_forward_distances_flat=batch.anchor_node_forward_distances_flat.to(
                device=graph_context.device,
                dtype=torch.long,
            ),
        )

    @property
    def device(self) -> torch.device:
        return self.target_mask.device


def build_outgoing_index(
    *,
    edge_index: torch.Tensor,
    num_nodes: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    src = edge_index[0]

    edge_ids = torch.arange(
        int(edge_index.size(1)),
        dtype=torch.long,
        device=edge_index.device,
    )

    order = torch.argsort(src)
    sorted_src = src.index_select(0, order)
    edge_ids_by_src = edge_ids.index_select(0, order)

    outgoing_count = torch.bincount(
        sorted_src,
        minlength=int(num_nodes),
    )

    outgoing_ptr = torch.empty(
        int(num_nodes) + 1,
        dtype=torch.long,
        device=edge_index.device,
    )

    outgoing_ptr[0] = 0
    outgoing_ptr[1:] = torch.cumsum(outgoing_count, dim=0)

    return outgoing_ptr, edge_ids_by_src


def edge_ptr_from_batch(
    *,
    batch: RetrievalBatch,
    graph_context: GraphContext,
) -> torch.Tensor:
    if hasattr(batch, "edge_batch") and batch.edge_batch is not None:
        edge_batch = batch.edge_batch.to(
            device=graph_context.device,
            dtype=torch.long,
        )
    else:
        edge_batch = graph_context.edge_to_graph.to(
            device=graph_context.device,
            dtype=torch.long,
        )

    edge_count_by_graph = torch.bincount(
        edge_batch,
        minlength=int(graph_context.num_graphs),
    )
    return torch.cat(
        [
            edge_count_by_graph.new_zeros(1),
            edge_count_by_graph.cumsum(dim=0),
        ],
        dim=0,
    )


__all__ = [
    "edge_ptr_from_batch",
    "GraphContext",
    "RewardContext",
    "build_outgoing_index",
]
