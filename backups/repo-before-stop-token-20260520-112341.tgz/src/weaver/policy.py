from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from src.graph.segments import segment_logsumexp
from src.utils.nn_utils import init_xavier
from src.weaver.context import GraphContext
from src.weaver.state import Frontier, State

from .nn.feature_encoder import EncodedFeatures
from .nn.state_encoder import StateEncoder


@dataclass(frozen=True, slots=True)
class PolicyOutput:
    state_log_flow: torch.Tensor
    stop_logit: torch.Tensor
    edge_logit: torch.Tensor
    frontier: Frontier


class Policy(nn.Module):
    """
    State-flow plus flat forward policy over actions:

        A(z) = {STOP} U Frontier(z)

    The model outputs one log-state-flow per state row and raw policy logits
    over STOP plus frontier actions. Log probabilities are derived outside the
    policy module by flat softmax normalization.
    """

    def __init__(
        self,
        *,
        state_encoder: StateEncoder,
    ) -> None:
        super().__init__()

        self.state_encoder = state_encoder
        hidden_dim = state_encoder.hidden_dim

        self.state_flow_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, 1),
        )

        self.stop_policy_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, 1),
        )

        self.edge_policy_head = nn.Sequential(
            nn.Linear(hidden_dim * 5, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, 1),
        )

        self.reset_parameters()

    @property
    def hidden_dim(self) -> int:
        return self.state_encoder.hidden_dim

    def forward(
        self,
        *,
        features: EncodedFeatures,
        state: State,
        context: GraphContext,
        frontier: Frontier,
    ) -> PolicyOutput:
        encoding = self.state_encoder(
            features=features,
            state=state,
            context=context,
        )

        state_log_flow = self.state_flow_head(encoding.row_state_h).squeeze(-1)
        stop_logits = self.stop_policy_head(encoding.row_state_h).squeeze(-1)
        edge_logits = self.edge_policy_logits(
            features=features,
            query_h=encoding.query_h,
            state_h=encoding.row_state_h,
            frontier=frontier,
        )
        return PolicyOutput(
            state_log_flow=state_log_flow,
            stop_logit=stop_logits,
            edge_logit=edge_logits,
            frontier=frontier,
        )

    def edge_policy_logits(
        self,
        *,
        features: EncodedFeatures,
        query_h: torch.Tensor,
        state_h: torch.Tensor,
        frontier: Frontier,
    ) -> torch.Tensor:
        row_ids = frontier.row_ids
        edge_ids = frontier.edge_ids

        if edge_ids.numel() == 0:
            return query_h.new_empty((0,))

        edge_h = self.state_encoder.encode_edge_tokens(
            features=features,
            src_node_ids=frontier.parent_node_ids,
            edge_ids=edge_ids,
            dst_node_ids=frontier.child_node_ids,
        )

        return self.edge_policy_head(
            torch.cat(
                [
                    query_h.index_select(0, row_ids),
                    state_h.index_select(0, row_ids),
                    edge_h,
                ],
                dim=-1,
            )
        ).squeeze(-1)

    def reset_parameters(self) -> None:
        for module in self.state_flow_head:
            if isinstance(module, nn.Linear):
                init_xavier(module)

        for module in self.stop_policy_head:
            if isinstance(module, nn.Linear):
                init_xavier(module)

        for module in self.edge_policy_head:
            if isinstance(module, nn.Linear):
                init_xavier(module)


def flat_policy_log_probs(
    *,
    stop_logit: torch.Tensor,
    edge_logit: torch.Tensor,
    frontier: Frontier,
) -> tuple[torch.Tensor, torch.Tensor]:
    stop = stop_logit.float().view(-1)
    edge = edge_logit.float().view(-1)

    if edge.numel() == 0:
        return torch.zeros_like(stop), edge

    edge_mass = segment_logsumexp(
        values=edge,
        segment_ids=frontier.row_ids,
        num_segments=int(stop.numel()),
    )
    log_z = torch.logaddexp(stop, edge_mass)

    return (
        stop - log_z,
        edge - log_z.index_select(0, frontier.row_ids),
    )


def normalize_flat_policy_logits(
    *,
    stop_logits: torch.Tensor,
    edge_logits: torch.Tensor,
    frontier: Frontier,
) -> tuple[torch.Tensor, torch.Tensor]:
    return flat_policy_log_probs(
        stop_logit=stop_logits,
        edge_logit=edge_logits,
        frontier=frontier,
    )


__all__ = [
    "flat_policy_log_probs",
    "normalize_flat_policy_logits",
    "Policy",
    "PolicyOutput",
]
