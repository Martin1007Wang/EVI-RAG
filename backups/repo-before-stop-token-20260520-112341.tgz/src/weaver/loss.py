from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

import torch
from torch import nn

from src.weaver.context import GraphContext, RewardContext
from src.weaver.nn.feature_encoder import EncodedFeatures
from src.weaver.policy import Policy, PolicyOutput, flat_policy_log_probs
from src.weaver.reward import Reward
from src.weaver.state import Frontier, State
from src.weaver.transitions import (
    TRANSITION_SOURCE_UNKNOWN,
    TRANSITION_SOURCE_POLICY,
    TRANSITION_SOURCE_REPLAY,
    TransitionBatch,
)


@dataclass(frozen=True, slots=True)
class LossOutput:
    loss: torch.Tensor
    metrics: dict[str, torch.Tensor]
    num_states: int
    per_unit_loss: torch.Tensor | None = None

    @staticmethod
    def aggregate(outputs: Sequence[LossOutput]) -> LossOutput:
        loss = torch.stack([x.loss for x in outputs]).mean()
        keys = set(outputs[0].metrics)
        for x in outputs[1:]:
            keys &= set(x.metrics)

        per_unit = [x.per_unit_loss.detach().flatten() for x in outputs if x.per_unit_loss is not None]

        return LossOutput(
            loss=loss,
            metrics={k: torch.stack([x.metrics[k] for x in outputs]).mean() for k in sorted(keys)},
            num_states=sum(x.num_states for x in outputs),
            per_unit_loss=torch.cat(per_unit) if per_unit else None,
        )


class StateFlowPolicyDBLoss(nn.Module):
    """
    DB loss for state-flow plus flat forward policy:

        A(z) = {STOP} ∪ Frontier(z)

    STOP:
        log F(z) + log P_F(STOP | z) = log R(z)

    EDGE:
        log F(z) + log P_F(z + e | z)
            = log F(z + e) + log P_B(z | z + e)
    """

    def __init__(
        self,
        *,
        alpha_replay: float = 1.0,
        lambda_stop: float = 1.0,
        lambda_subtb: float = 0.1,
        subtb_max_len: int | None = None,
        residual_loss: str = "huber",
        huber_delta: float = 2.0,
    ) -> None:
        super().__init__()
        self.alpha_replay = float(alpha_replay)
        self.lambda_stop = float(lambda_stop)
        self.lambda_subtb = float(lambda_subtb)
        self.subtb_max_len = None if subtb_max_len is None else int(subtb_max_len)
        self.residual_loss = residual_loss
        self.huber_delta = float(huber_delta)
        self.backward_policy = UniformLeafBackwardPolicy()

    def forward(
        self,
        *,
        policy: Policy,
        reward_model: Reward,
        transitions: TransitionBatch,
        context: GraphContext,
        reward_context: RewardContext,
        features: EncodedFeatures,
    ) -> LossOutput:
        parent = transitions.parent_state
        child = transitions.child_state
        action_edge_ids = transitions.action_edge_ids
        source_ids = transitions.source_ids

        parent_frontier = parent.frontier(context)
        child_frontier = child.frontier(context)

        parent_out = policy(
            features=features,
            state=parent,
            context=context,
            frontier=parent_frontier,
        )
        child_out = policy(
            features=features,
            state=child,
            context=context,
            frontier=child_frontier,
        )

        parent_reward = reward_model(state=parent, context=reward_context)

        child_flow = state_log_flow(child_out)
        log_pb = backward_action_log_prob(
            backward_policy=self.backward_policy,
            child_state=child,
            context=context,
            action_edge_ids=action_edge_ids,
        )

        stop_mask = action_edge_ids.lt(0)
        edge_mask = action_edge_ids.ge(0)

        parent_flow = state_log_flow(parent_out)
        parent_stop_log_prob, _ = flat_policy_log_probs(
            stop_logit=parent_out.stop_logit,
            edge_logit=parent_out.edge_logit,
            frontier=parent_frontier,
        )
        parent_action_log_prob = forward_action_log_prob(
            policy_out=parent_out,
            action_edge_ids=action_edge_ids,
            num_edges=int(context.num_edges),
        )

        stop_residual = (
            parent_flow
            + parent_stop_log_prob.float()
            - parent_reward.log_reward.float()
        )

        if bool(edge_mask.any()):
            edge_residual = (
                parent_flow[edge_mask]
                + parent_action_log_prob[edge_mask]
                - child_flow[edge_mask]
                - log_pb[edge_mask]
            )
        else:
            edge_residual = parent_flow.new_empty((0,))

        edge_units = residual_loss_units(
            edge_residual,
            loss_type=self.residual_loss,
            huber_delta=self.huber_delta,
        )
        stop_units = residual_loss_units(
            stop_residual,
            loss_type=self.residual_loss,
            huber_delta=self.huber_delta,
        )
        subtb_residual, subtb_source_ids = subtrajectory_balance_residuals(
            parent_flow=parent_flow,
            child_flow=child_flow,
            action_log_prob=parent_action_log_prob,
            log_pb=log_pb,
            log_reward=parent_reward.log_reward.float(),
            action_edge_ids=action_edge_ids,
            trajectory_ids=transitions.trajectory_ids,
            step_ids=transitions.step_ids,
            source_ids=source_ids,
            max_len=self.subtb_max_len,
            enabled=self.lambda_subtb != 0.0,
        )
        subtb_units = residual_loss_units(
            subtb_residual,
            loss_type=self.residual_loss,
            huber_delta=self.huber_delta,
        )

        policy_mask = source_ids.eq(TRANSITION_SOURCE_POLICY)
        replay_mask = source_ids.eq(TRANSITION_SOURCE_REPLAY)

        edge_loss = source_balanced_mean(
            edge_units,
            source_ids[edge_mask],
            alpha_replay=self.alpha_replay,
        )
        stop_loss = source_balanced_mean(
            stop_units,
            source_ids,
            alpha_replay=self.alpha_replay,
        )
        subtb_loss = source_balanced_mean(
            subtb_units,
            subtb_source_ids,
            alpha_replay=self.alpha_replay,
        )
        loss = edge_loss + self.lambda_stop * stop_loss + self.lambda_subtb * subtb_loss

        metrics = {
            "loss/main": loss.detach(),
            "loss/edge_db": edge_loss.detach(),
            "loss/stop_db": stop_loss.detach(),
            "loss/subtb": subtb_loss.detach(),
            "loss/edge": edge_loss.detach(),
            "loss/stop": stop_loss.detach(),
            "flow/state_log_flow_mean": parent_flow.mean().detach(),
            "policy/stop_log_prob_mean": parent_stop_log_prob.float().mean().detach(),
            "policy/edge_log_prob_mean": mean_or_zero(edge_log_probs(parent_out).float()).detach(),
            "policy/stop_prob_mean": stop_probability(parent_out).mean().detach(),
            "policy/edge_prob_mass_mean": edge_probability_mass(parent_out).mean().detach(),
            "policy/answer_hit_then_continue": masked_fraction(
                edge_mask & parent_reward.supported_count.gt(0) & policy_mask,
                parent_reward.supported_count.gt(0) & policy_mask,
            ).detach(),
            "source/policy_num_transitions": policy_mask.float().sum().detach(),
            "source/replay_num_transitions": replay_mask.float().sum().detach(),
            "subtb/num_segments": torch.tensor(
                float(subtb_residual.numel()),
                dtype=parent_flow.dtype,
                device=parent_flow.device,
            ).detach(),
        }
        metrics.update(
            stop_probability_by_depth(
                stop_log_prob=parent_stop_log_prob,
                step_ids=transitions.step_ids,
            )
        )
        metrics.update(
            rollout_metrics(
                source_ids=source_ids,
                action_edge_ids=action_edge_ids,
                step_ids=transitions.step_ids,
                frontier=parent_frontier,
                num_rows=parent.num_rows,
            )
        )

        return LossOutput(
            loss=loss,
            metrics=metrics,
            num_states=int(parent.num_rows),
            per_unit_loss=torch.cat(
                [
                    edge_units.detach().flatten(),
                    stop_units.detach().flatten(),
                    subtb_units.detach().flatten(),
                ]
            ),
        )


def state_log_flow(policy_out: PolicyOutput) -> torch.Tensor:
    return policy_out.state_log_flow.float()


def stop_probability(
    policy_out: PolicyOutput,
    state_flow: torch.Tensor | None = None,
) -> torch.Tensor:
    del state_flow
    stop_log_prob, _ = flat_policy_log_probs(
        stop_logit=policy_out.stop_logit,
        edge_logit=policy_out.edge_logit,
        frontier=policy_out.frontier,
    )
    return stop_log_prob.float().exp()


def edge_probability_mass(
    policy_out: PolicyOutput,
    state_flow: torch.Tensor | None = None,
) -> torch.Tensor:
    del state_flow
    out = torch.zeros_like(policy_out.state_log_flow.float())

    edge_log_prob = edge_log_probs(policy_out)
    if edge_log_prob.numel() == 0:
        return out

    prob = edge_log_prob.float().exp()
    out.scatter_add_(0, policy_out.frontier.row_ids, prob)
    return out


def edge_log_probs(policy_out: PolicyOutput) -> torch.Tensor:
    _, edge_log_prob = flat_policy_log_probs(
        stop_logit=policy_out.stop_logit,
        edge_logit=policy_out.edge_logit,
        frontier=policy_out.frontier,
    )
    return edge_log_prob.float()


def forward_action_log_prob(
    *,
    policy_out: PolicyOutput,
    action_edge_ids: torch.Tensor,
    num_edges: int,
) -> torch.Tensor:
    action_edge_ids = action_edge_ids.to(
        device=policy_out.state_log_flow.device,
        dtype=torch.long,
    ).view(-1)
    out = torch.empty(
        action_edge_ids.numel(),
        dtype=torch.float32,
        device=policy_out.state_log_flow.device,
    )
    stop_mask = action_edge_ids.lt(0)
    edge_mask = action_edge_ids.ge(0)
    stop_log_prob, edge_log_prob = flat_policy_log_probs(
        stop_logit=policy_out.stop_logit,
        edge_logit=policy_out.edge_logit,
        frontier=policy_out.frontier,
    )

    if bool(stop_mask.any()):
        out[stop_mask] = stop_log_prob.float()[stop_mask]

    if bool(edge_mask.any()):
        edge_rows = edge_mask.nonzero(as_tuple=False).flatten()
        edge_pos = selected_frontier_position(
            frontier=policy_out.frontier,
            row_ids=edge_rows,
            action_edge_ids=action_edge_ids[edge_mask],
            num_edges=int(num_edges),
        )
        out[edge_mask] = edge_log_prob.float().index_select(0, edge_pos)

    return out


def selected_frontier_position(
    *,
    frontier: Frontier,
    row_ids: torch.Tensor,
    action_edge_ids: torch.Tensor,
    num_edges: int,
) -> torch.Tensor:
    key = frontier.row_ids * int(num_edges) + frontier.edge_ids
    target = row_ids * int(num_edges) + action_edge_ids

    order = torch.argsort(key)
    return order[torch.searchsorted(key[order], target)]


def backward_action_log_prob(
    *,
    backward_policy: "UniformLeafBackwardPolicy",
    child_state: State,
    context: GraphContext,
    action_edge_ids: torch.Tensor,
) -> torch.Tensor:
    out = action_edge_ids.new_zeros(action_edge_ids.numel()).float()
    edge_mask = action_edge_ids.ge(0)

    if bool(edge_mask.any()):
        out[edge_mask] = backward_policy.log_prob(
            state=child_state,
            context=context,
        )[edge_mask]

    return out


def subtrajectory_balance_residuals(
    *,
    parent_flow: torch.Tensor,
    child_flow: torch.Tensor,
    action_log_prob: torch.Tensor,
    log_pb: torch.Tensor,
    log_reward: torch.Tensor,
    action_edge_ids: torch.Tensor,
    trajectory_ids: torch.Tensor,
    step_ids: torch.Tensor,
    source_ids: torch.Tensor,
    max_len: int | None,
    enabled: bool,
) -> tuple[torch.Tensor, torch.Tensor]:
    if not enabled or action_edge_ids.numel() == 0:
        return (
            parent_flow.new_empty((0,)),
            source_ids.new_empty((0,)),
        )

    if max_len is not None and int(max_len) < 2:
        return (
            parent_flow.new_empty((0,)),
            source_ids.new_empty((0,)),
        )

    trajectory_ids = trajectory_ids.to(device=action_edge_ids.device, dtype=torch.long).view(-1)
    step_ids = step_ids.to(device=action_edge_ids.device, dtype=torch.long).view(-1)
    source_ids = source_ids.to(device=action_edge_ids.device, dtype=torch.long).view(-1)

    order = torch.argsort(trajectory_ids * (int(step_ids.max().item()) + 2) + step_ids)
    residuals: list[torch.Tensor] = []
    residual_sources: list[torch.Tensor] = []

    unique_trajectories = torch.unique(trajectory_ids.index_select(0, order), sorted=True)
    for trajectory_id in unique_trajectories.tolist():
        group = order[trajectory_ids.index_select(0, order).eq(int(trajectory_id))]
        n = int(group.numel())
        if n < 2:
            continue

        for start_pos in range(n):
            start_idx = group[start_pos]
            running_log_pf = parent_flow.new_zeros(())
            running_log_pb = parent_flow.new_zeros(())
            prev_step: int | None = None
            limit = n if max_len is None else min(n, start_pos + int(max_len))

            for end_pos in range(start_pos, limit):
                idx = group[end_pos]
                step = int(step_ids[idx].item())
                if prev_step is not None and step != prev_step + 1:
                    break
                prev_step = step

                running_log_pf = running_log_pf + action_log_prob[idx]
                is_stop = bool(action_edge_ids[idx].lt(0).item())
                if not is_stop:
                    running_log_pb = running_log_pb + log_pb[idx]

                length = end_pos - start_pos + 1
                if is_stop:
                    if length >= 2:
                        residuals.append(
                            parent_flow[start_idx]
                            + running_log_pf
                            - log_reward[idx]
                            - running_log_pb
                        )
                        residual_sources.append(source_ids[start_idx])
                    break

                if length >= 2:
                    residuals.append(
                        parent_flow[start_idx]
                        + running_log_pf
                        - child_flow[idx]
                        - running_log_pb
                    )
                    residual_sources.append(source_ids[start_idx])

    if not residuals:
        return (
            parent_flow.new_empty((0,)),
            source_ids.new_empty((0,)),
        )

    return torch.stack(residuals), torch.stack(residual_sources).to(dtype=torch.long)


class UniformLeafBackwardPolicy(nn.Module):
    def forward(
        self,
        *,
        state: State,
        context: GraphContext,
    ) -> torch.Tensor:
        return self.log_prob(state=state, context=context)

    def log_prob(
        self,
        *,
        state: State,
        context: GraphContext,
    ) -> torch.Tensor:
        return (
            -selected_leaf_edge_count(
                state=state,
                context=context,
            )
            .clamp_min(1)
            .float()
            .log()
        )


def selected_leaf_edge_count(
    *,
    state: State,
    context: GraphContext,
) -> torch.Tensor:
    out = torch.zeros(
        state.num_rows,
        device=state.device,
        dtype=torch.long,
    )

    rows, edge_ids = state.edge_mask.nonzero(as_tuple=True)
    if edge_ids.numel() == 0:
        return out

    src = context.edge_index[0][edge_ids]
    dst = context.edge_index[1][edge_ids]

    src_key = rows * int(context.num_nodes) + src
    dst_key = rows * int(context.num_nodes) + dst

    order = torch.argsort(src_key)
    sorted_src = src_key[order]

    pos = torch.searchsorted(sorted_src, dst_key)
    pos = pos.clamp_max(sorted_src.numel() - 1)

    has_child = sorted_src[pos].eq(dst_key)
    leaf_rows = rows[~has_child]

    return out.scatter_add(
        0,
        leaf_rows,
        torch.ones_like(leaf_rows),
    )


def residual_loss_units(
    residual: torch.Tensor,
    *,
    loss_type: str,
    huber_delta: float,
) -> torch.Tensor:
    if loss_type == "mse":
        return residual.square()

    delta = float(huber_delta)
    abs_residual = residual.abs()
    return torch.where(
        abs_residual <= delta,
        0.5 * residual.square(),
        delta * (abs_residual - 0.5 * delta),
    )


def rollout_metrics(
    *,
    source_ids: torch.Tensor,
    action_edge_ids: torch.Tensor,
    step_ids: torch.Tensor,
    frontier: Frontier,
    num_rows: int,
) -> dict[str, torch.Tensor]:
    policy = source_ids.eq(TRANSITION_SOURCE_POLICY)
    stop = policy & action_edge_ids.lt(0)
    forced = stop & ~rows_with_frontier(frontier=frontier, num_rows=num_rows)

    return {
        "rollout/stop_rate": masked_fraction(stop, policy).detach(),
        "rollout/forced_stop_rate": masked_fraction(forced, stop).detach(),
        "rollout/mean_stop_depth": masked_mean_or_zero(
            step_ids.float(),
            stop,
        ).detach(),
    }


def source_rollout_metrics(
    *,
    source_ids: torch.Tensor,
    action_edge_ids: torch.Tensor,
    step_ids: torch.Tensor,
    parent_frontier: Frontier,
    num_rows: int,
) -> dict[str, torch.Tensor]:
    metrics = rollout_metrics(
        source_ids=source_ids,
        action_edge_ids=action_edge_ids,
        step_ids=step_ids,
        frontier=parent_frontier,
        num_rows=int(num_rows),
    )
    return {
        **metrics,
        "rollout/mean_depth": metrics["rollout/mean_stop_depth"],
    }


def rows_with_frontier(
    *,
    frontier: Frontier,
    num_rows: int,
) -> torch.Tensor:
    out = torch.zeros(
        int(num_rows),
        dtype=torch.bool,
        device=frontier.row_ids.device,
    )

    if frontier.row_ids.numel() > 0:
        out.index_fill_(0, frontier.row_ids, True)

    return out


def masked_mean_or_zero(
    values: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    if not bool(mask.any()):
        return values.new_zeros(())
    return values.float()[mask].mean()


def source_balanced_mean(
    values: torch.Tensor,
    source_ids: torch.Tensor,
    *,
    alpha_replay: float,
) -> torch.Tensor:
    if values.numel() == 0:
        return values.new_zeros(())

    source_ids = source_ids.to(device=values.device, dtype=torch.long).view(-1)
    policy_mask = source_ids.eq(TRANSITION_SOURCE_POLICY) | source_ids.eq(
        TRANSITION_SOURCE_UNKNOWN,
    )
    replay_mask = source_ids.eq(TRANSITION_SOURCE_REPLAY)
    policy_loss = masked_mean_or_zero(values, policy_mask)
    replay_loss = masked_mean_or_zero(values, replay_mask)

    if not bool(policy_mask.any()):
        return float(alpha_replay) * replay_loss
    if not bool(replay_mask.any()):
        return policy_loss
    return policy_loss + float(alpha_replay) * replay_loss


def masked_fraction(
    numerator: torch.Tensor,
    denominator: torch.Tensor,
) -> torch.Tensor:
    count = denominator.float().sum()
    if not bool(count.gt(0)):
        return count.new_zeros(())
    return numerator.float().sum() / count


def mean_or_zero(values: torch.Tensor) -> torch.Tensor:
    if values.numel() == 0:
        return values.new_zeros(())
    return values.mean()


def stop_probability_by_depth(
    *,
    stop_log_prob: torch.Tensor,
    step_ids: torch.Tensor,
) -> dict[str, torch.Tensor]:
    metrics: dict[str, torch.Tensor] = {}
    if step_ids.numel() == 0:
        return metrics

    step_ids = step_ids.to(device=stop_log_prob.device, dtype=torch.long).view(-1)
    stop_prob = stop_log_prob.float().exp()
    for depth in torch.unique(step_ids, sorted=True).tolist():
        mask = step_ids.eq(int(depth))
        metrics[f"policy/stop_prob_by_depth/{int(depth)}"] = masked_mean_or_zero(
            stop_prob,
            mask,
        ).detach()
    return metrics


__all__ = [
    "edge_log_probs",
    "LossOutput",
    "StateFlowPolicyDBLoss",
    "UniformLeafBackwardPolicy",
    "backward_action_log_prob",
    "edge_probability_mass",
    "forward_action_log_prob",
    "residual_loss_units",
    "selected_frontier_position",
    "selected_leaf_edge_count",
    "source_rollout_metrics",
    "state_log_flow",
    "stop_probability",
    "subtrajectory_balance_residuals",
]
