from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

import torch

from src.weaver.context import GraphContext


@dataclass(frozen=True, slots=True)
class Frontier:
    row_ids: torch.Tensor
    edge_ids: torch.Tensor
    parent_node_ids: torch.Tensor
    child_node_ids: torch.Tensor

    @property
    def num_actions(self) -> int:
        return int(self.edge_ids.numel())

    @property
    def is_empty(self) -> bool:
        return self.edge_ids.numel() == 0


@dataclass(slots=True)
class State:
    """
    Dynamic rollout state.

    Truth:
        node_mask:         [R, N], bool
        edge_mask:         [R, E], bool
        max_budget_by_row: [R], long
        row_to_graph:      [R], long

    Frontier:
        C(z; G) is derived from this state and GraphContext.
    """

    node_mask: torch.Tensor
    edge_mask: torch.Tensor
    max_budget_by_row: torch.Tensor
    row_to_graph: torch.Tensor

    @classmethod
    def initial(
        cls,
        *,
        context: GraphContext,
        budget: int,
        rollouts_per_graph: int,
    ) -> State:
        num_rows = int(context.num_graphs) * int(rollouts_per_graph)

        node_mask = torch.zeros(
            (num_rows, int(context.num_nodes)),
            dtype=torch.bool,
            device=context.device,
        )

        edge_mask = torch.zeros(
            (num_rows, int(context.num_edges)),
            dtype=torch.bool,
            device=context.device,
        )

        max_budget_by_row = torch.full(
            (num_rows,),
            int(budget),
            dtype=torch.long,
            device=context.device,
        )

        row_to_graph = torch.arange(
            int(context.num_graphs),
            dtype=torch.long,
            device=context.device,
        ).repeat_interleave(int(rollouts_per_graph))

        anchors = context.anchor_mask.nonzero(as_tuple=True)[0]

        if anchors.numel() > 0:
            anchor_graph = context.node_to_graph.index_select(0, anchors)

            rollout_offsets = torch.arange(
                int(rollouts_per_graph),
                dtype=torch.long,
                device=context.device,
            )

            rows = anchor_graph.repeat_interleave(int(rollouts_per_graph)) * int(rollouts_per_graph) + rollout_offsets.repeat(int(anchors.numel()))

            cols = anchors.repeat_interleave(int(rollouts_per_graph))
            node_mask[rows, cols] = True

        return cls(
            node_mask=node_mask,
            edge_mask=edge_mask,
            max_budget_by_row=max_budget_by_row,
            row_to_graph=row_to_graph,
        )

    @property
    def device(self) -> torch.device:
        return self.edge_mask.device

    @property
    def num_rollouts(self) -> int:
        return int(self.edge_mask.size(0))

    @property
    def num_rows(self) -> int:
        return int(self.edge_mask.size(0))

    @property
    def num_nodes(self) -> int:
        return int(self.node_mask.size(1))

    @property
    def num_edges(self) -> int:
        return int(self.edge_mask.size(1))

    @property
    def remaining_budget(self) -> torch.Tensor:
        return self.max_budget_by_row - self.edge_mask.long().sum(dim=1)

    def clone(self) -> State:
        return State(
            node_mask=self.node_mask.clone(),
            edge_mask=self.edge_mask.clone(),
            max_budget_by_row=self.max_budget_by_row.clone(),
            row_to_graph=self.row_to_graph.clone(),
        )

    def select_rows(self, rows: torch.Tensor) -> State:
        return State(
            node_mask=self.node_mask.index_select(0, rows),
            edge_mask=self.edge_mask.index_select(0, rows),
            max_budget_by_row=self.max_budget_by_row.index_select(0, rows),
            row_to_graph=self.row_to_graph.index_select(0, rows),
        )

    @classmethod
    def concat(cls, states: Sequence[State]) -> State:
        return cls(
            node_mask=torch.cat([s.node_mask for s in states], dim=0),
            edge_mask=torch.cat([s.edge_mask for s in states], dim=0),
            max_budget_by_row=torch.cat([s.max_budget_by_row for s in states], dim=0),
            row_to_graph=torch.cat([s.row_to_graph for s in states], dim=0),
        )

    def active_nodes(self) -> tuple[torch.Tensor, torch.Tensor]:
        return self.node_mask.nonzero(as_tuple=True)

    def selected_edges(self) -> tuple[torch.Tensor, torch.Tensor]:
        return self.edge_mask.nonzero(as_tuple=True)

    def frontier(self, context: GraphContext) -> Frontier:
        rows, nodes = self.node_mask.nonzero(as_tuple=True)

        if rows.numel() == 0:
            return empty_frontier(self.device)

        has_budget = self.remaining_budget.index_select(0, rows).gt(0)
        rows = rows[has_budget]
        nodes = nodes[has_budget]

        if rows.numel() == 0:
            return empty_frontier(self.device)

        starts = context.outgoing_ptr.index_select(0, nodes)
        ends = context.outgoing_ptr.index_select(0, nodes + 1)
        degrees = ends - starts

        has_degree = degrees.gt(0)
        rows = rows[has_degree]
        starts = starts[has_degree]
        degrees = degrees[has_degree]

        if rows.numel() == 0:
            return empty_frontier(self.device)

        frontier_rows = torch.repeat_interleave(rows, degrees)
        edge_pos = torch.repeat_interleave(starts, degrees) + segment_arange(degrees)
        edge_ids = context.edge_ids_by_src.index_select(0, edge_pos)

        same_graph = context.edge_to_graph.index_select(0, edge_ids).eq(self.row_to_graph.index_select(0, frontier_rows))

        frontier_rows = frontier_rows[same_graph]
        edge_ids = edge_ids[same_graph]

        if edge_ids.numel() == 0:
            return empty_frontier(self.device)

        unselected = ~self.edge_mask[frontier_rows, edge_ids]
        frontier_rows = frontier_rows[unselected]
        edge_ids = edge_ids[unselected]

        if edge_ids.numel() == 0:
            return empty_frontier(self.device)

        src = context.edge_index[0].index_select(0, edge_ids)
        dst = context.edge_index[1].index_select(0, edge_ids)

        expands_new_node = self.node_mask[frontier_rows, src] & ~self.node_mask[frontier_rows, dst]

        return Frontier(
            row_ids=frontier_rows[expands_new_node],
            edge_ids=edge_ids[expands_new_node],
            parent_node_ids=src[expands_new_node],
            child_node_ids=dst[expands_new_node],
        )

    def apply_edges_(
        self,
        *,
        context: GraphContext,
        row_ids: torch.Tensor,
        edge_ids: torch.Tensor,
    ) -> None:
        if edge_ids.numel() == 0:
            return

        dst = context.edge_index[1].index_select(0, edge_ids)

        self.edge_mask[row_ids, edge_ids] = True
        self.node_mask[row_ids, dst] = True


def empty_frontier(device: torch.device) -> Frontier:
    empty = torch.empty(
        0,
        dtype=torch.long,
        device=device,
    )

    return Frontier(
        row_ids=empty,
        edge_ids=empty,
        parent_node_ids=empty,
        child_node_ids=empty,
    )


def segment_arange(lengths: torch.Tensor) -> torch.Tensor:
    total = int(lengths.sum().item())

    if total == 0:
        return torch.empty(
            0,
            dtype=torch.long,
            device=lengths.device,
        )

    starts = torch.cumsum(lengths, dim=0) - lengths

    return torch.arange(
        total,
        dtype=torch.long,
        device=lengths.device,
    ) - torch.repeat_interleave(starts, lengths)


__all__ = [
    "Frontier",
    "State",
]
