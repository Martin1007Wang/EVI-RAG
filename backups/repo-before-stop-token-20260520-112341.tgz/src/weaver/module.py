from __future__ import annotations

from collections.abc import Mapping

import torch
from lightning import LightningModule
from lightning.pytorch.utilities.types import OptimizerLRScheduler
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, LinearLR, SequentialLR

from src.data.schema import RetrievalBatch
from src.training.config import EvalRuntimeConfig, OptimizationRuntimeConfig
from src.training.metrics import WeaverMetricSuite
from src.weaver.context import GraphContext, RewardContext
from src.weaver.loss import LossOutput, StateFlowPolicyDBLoss
from src.weaver.nn.feature_encoder import FeatureEncoder
from src.weaver.policy import Policy
from src.weaver.reward import Reward
from src.weaver.rollout.result import RolloutResult
from src.weaver.rollout.runner import RolloutRunner

Scalar = torch.Tensor | float | int


class WeaverModule(LightningModule):
    """
    Lightning wrapper for Weaver.

    Responsibilities:
        - build GraphContext / RewardContext
        - encode features
        - call rollout runner
        - call loss model
        - log metrics
        - build optimizer / scheduler

    Non-responsibilities:
        - frontier construction
        - action sampling
        - transition reconstruction
        - reward internals
        - policy-output matching
        - manual Bellman residual construction
    """

    def __init__(
        self,
        *,
        feature_encoder: FeatureEncoder,
        policy: Policy,
        reward_model: Reward,
        loss_model: StateFlowPolicyDBLoss,
        runner: RolloutRunner,
        optimization: OptimizationRuntimeConfig,
        evaluation: EvalRuntimeConfig,
        train_temperature: float = 1.0,
        eval_temperature: float = 1.0,
    ) -> None:
        super().__init__()

        self.feature_encoder = feature_encoder
        self.policy = policy
        self.reward_model = reward_model
        self.loss_model = loss_model
        self.runner = runner

        self.optimization = optimization
        self.evaluation = evaluation

        self.metric_suite = WeaverMetricSuite(
            k_windows=evaluation.k_windows,
            exclude_anchors_from_retrieved=evaluation.exclude_anchors_from_retrieved,
            use_reachable_targets=evaluation.use_reachable_targets,
        )

        self.train_temperature = float(train_temperature)
        self.eval_temperature = float(eval_temperature)

        self.runner.progress_fn = self.training_progress

        self.save_hyperparameters(
            {
                "train_temperature": self.train_temperature,
                "eval_temperature": self.eval_temperature,
            }
        )

    def configure_optimizers(self) -> OptimizerLRScheduler:
        optimizer = self.build_optimizer()
        scheduler = self.build_scheduler(optimizer)

        if scheduler is None:
            return optimizer

        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": scheduler,
                "interval": self.optimization.scheduler.interval,
            },
        }

    def training_step(
        self,
        batch: RetrievalBatch,
        batch_idx: int,
    ) -> torch.Tensor:
        del batch_idx

        context = GraphContext.from_batch(batch)
        reward_context = RewardContext.from_batch(
            batch=batch,
            graph_context=context,
            expand_budget=self.runner.engine.expand_budget,
        )

        with torch.no_grad():
            rollout_features = self.feature_encoder(batch)
            rollout_batch = self.runner.train_rollouts(
                policy=self.policy,
                batch=batch,
                context=context,
                features=rollout_features,
                temperature=self.train_temperature,
            )

        if rollout_batch.transitions is None or rollout_batch.transitions.num_transitions <= 0:
            raise RuntimeError("No training transitions were produced. " "Check rollout sampling, replay source, and transition construction.")

        features = self.feature_encoder(batch)

        output = self.loss_model(
            policy=self.policy,
            reward_model=self.reward_model,
            transitions=rollout_batch.transitions,
            context=context,
            reward_context=reward_context,
            features=features,
        )

        self.log_loss_output(
            prefix="train",
            output=output,
            batch_size=batch_size(batch),
            on_step=False,
            on_epoch=True,
        )

        self.log(
            "train/signal/rollouts",
            float(rollout_batch.num_rollouts),
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            batch_size=batch_size(batch),
            sync_dist=True,
        )

        self.log(
            "train/signal/transitions",
            float(rollout_batch.num_transitions),
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            batch_size=batch_size(batch),
            sync_dist=True,
        )

        self.log(
            "train/signal/replay_trajectories",
            float(rollout_batch.num_replay_trajectories),
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            batch_size=batch_size(batch),
            sync_dist=True,
        )

        self.log(
            "train/signal/replay_transitions",
            float(rollout_batch.num_replay_transitions),
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            batch_size=batch_size(batch),
            sync_dist=True,
        )

        self.log(
            "train/signal/replay_terminal_transitions",
            float(rollout_batch.num_replay_terminal_transitions),
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            batch_size=batch_size(batch),
            sync_dist=True,
        )

        return output.loss

    def validation_step(
        self,
        batch: RetrievalBatch,
        batch_idx: int,
    ) -> None:
        del batch_idx
        self.eval_step(split="val", batch=batch)

    def test_step(
        self,
        batch: RetrievalBatch,
        batch_idx: int,
    ) -> None:
        del batch_idx
        self.eval_step(split="test", batch=batch)

    def predict_step(
        self,
        batch: RetrievalBatch,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> tuple[RolloutResult, ...]:
        del batch_idx, dataloader_idx

        with torch.no_grad():
            context = GraphContext.from_batch(batch)
            features = self.feature_encoder(batch)

            return self.runner.eval_rollouts(
                policy=self.policy,
                context=context,
                features=features,
                temperature=self.eval_temperature,
            )

    def eval_step(
        self,
        *,
        split: str,
        batch: RetrievalBatch,
    ) -> None:
        with torch.no_grad():
            context = GraphContext.from_batch(batch)
            reward_context = RewardContext.from_batch(
                batch=batch,
                graph_context=context,
                expand_budget=self.runner.engine.expand_budget,
            )
            features = self.feature_encoder(batch)

            rollouts = self.runner.eval_rollouts(
                policy=self.policy,
                context=context,
                features=features,
                temperature=self.eval_temperature,
            )

            metrics = self.metric_suite.eval_metrics(
                rollout_samples=rollouts,
                batch=batch,
                stage="",
                context=context,
                features=features,
                reward_model=self.reward_model,
                reward_context=reward_context,
            )

        batch_n = batch_size(batch)

        self.log(
            f"{split}/num_rollouts",
            float(len(rollouts)),
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            batch_size=batch_n,
            sync_dist=True,
        )

        self.log_scalars(
            prefix=split,
            values=metrics,
            batch_size=batch_n,
            on_step=False,
            on_epoch=True,
        )

    def build_optimizer(self) -> torch.optim.Optimizer:
        cfg = self.optimization.optimizer

        if cfg.no_decay_on_bias_and_norm:
            parameters = parameter_groups_without_decay(
                self,
                weight_decay=cfg.weight_decay,
            )
        else:
            parameters = self.parameters()

        return AdamW(
            parameters,
            lr=cfg.lr,
            betas=cfg.betas,
            weight_decay=cfg.weight_decay,
        )

    def build_scheduler(
        self,
        optimizer: torch.optim.Optimizer,
    ) -> torch.optim.lr_scheduler.LRScheduler | None:
        cfg = self.optimization.scheduler

        if cfg is None:
            return None

        horizon = scheduler_horizon(
            trainer=self.trainer,
            interval=cfg.interval,
        )

        warmup_steps = int(float(horizon) * float(cfg.warmup_ratio))
        cosine_steps = max(1, int(horizon) - warmup_steps)

        cosine = CosineAnnealingLR(
            optimizer,
            T_max=cosine_steps,
            eta_min=cfg.eta_min,
        )

        if warmup_steps <= 0:
            return cosine

        warmup = LinearLR(
            optimizer,
            start_factor=1.0e-8,
            end_factor=1.0,
            total_iters=warmup_steps,
        )

        return SequentialLR(
            optimizer,
            schedulers=[warmup, cosine],
            milestones=[warmup_steps],
        )

    def training_progress(self) -> float:
        try:
            trainer = self.trainer
        except RuntimeError:
            return 0.0

        horizon = scheduler_horizon(
            trainer=trainer,
            interval="step",
        )

        if horizon <= 0:
            return 0.0

        step = int(getattr(trainer, "global_step", 0))

        return min(
            1.0,
            max(
                0.0,
                float(step) / float(horizon),
            ),
        )

    def log_loss_output(
        self,
        *,
        prefix: str,
        output: LossOutput,
        batch_size: int,
        on_step: bool,
        on_epoch: bool,
    ) -> None:
        self.log(
            f"{prefix}/loss",
            output.loss,
            on_step=on_step,
            on_epoch=on_epoch,
            prog_bar=True,
            batch_size=batch_size,
            sync_dist=True,
        )

        self.log(
            f"{prefix}/signal/num_states",
            float(output.num_states),
            on_step=on_step,
            on_epoch=on_epoch,
            prog_bar=False,
            batch_size=batch_size,
            sync_dist=True,
        )

        self.log_scalars(
            prefix=prefix,
            values=output.metrics,
            batch_size=batch_size,
            on_step=on_step,
            on_epoch=on_epoch,
        )

    def log_scalars(
        self,
        *,
        prefix: str,
        values: Mapping[str, Scalar],
        batch_size: int,
        on_step: bool,
        on_epoch: bool,
    ) -> None:
        for name, value in values.items():
            self.log(
                f"{prefix}/{name}",
                scalar_tensor(value, device=self.device),
                on_step=on_step,
                on_epoch=on_epoch,
                prog_bar=False,
                batch_size=batch_size,
                sync_dist=True,
            )


def scalar_tensor(
    value: Scalar,
    *,
    device: torch.device,
) -> torch.Tensor:
    if isinstance(value, torch.Tensor):
        return value.detach().to(device=device)

    return torch.tensor(
        float(value),
        device=device,
    )


def batch_size(batch: RetrievalBatch) -> int:
    return int(batch.num_graphs_total)


def parameter_groups_without_decay(
    module: torch.nn.Module,
    *,
    weight_decay: float,
) -> list[dict[str, object]]:
    decay: list[torch.nn.Parameter] = []
    no_decay: list[torch.nn.Parameter] = []

    for name, parameter in module.named_parameters():
        if not parameter.requires_grad:
            continue

        if name.endswith(".bias") or parameter.ndim <= 1:
            no_decay.append(parameter)
        else:
            decay.append(parameter)

    groups: list[dict[str, object]] = []

    if decay:
        groups.append(
            {
                "params": decay,
                "weight_decay": float(weight_decay),
            }
        )

    if no_decay:
        groups.append(
            {
                "params": no_decay,
                "weight_decay": 0.0,
            }
        )

    return groups


def scheduler_horizon(
    *,
    trainer: object,
    interval: str,
) -> int:
    if interval == "step":
        max_steps = getattr(trainer, "max_steps", None)
        if isinstance(max_steps, int) and max_steps > 0:
            return int(max_steps)

        estimated = getattr(trainer, "estimated_stepping_batches", None)
        if isinstance(estimated, int) and estimated > 0:
            return int(estimated)

        return 0

    if interval == "epoch":
        max_epochs = getattr(trainer, "max_epochs", None)
        if isinstance(max_epochs, int) and max_epochs > 0:
            return int(max_epochs)

        return 0

    raise ValueError(f"Unsupported scheduler interval: {interval!r}.")


__all__ = [
    "WeaverModule",
]
