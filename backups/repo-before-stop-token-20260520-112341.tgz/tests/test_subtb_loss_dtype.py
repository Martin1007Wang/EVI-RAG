from __future__ import annotations

import torch

from src.weaver.loss import (
    edge_probability_mass,
    forward_action_log_prob,
    state_log_flow,
    stop_probability,
    subtrajectory_balance_residuals,
)
from src.weaver.policy import PolicyOutput
from src.weaver.state import Frontier


def test_forward_action_log_prob_uses_float32_for_bf16_policy_outputs() -> None:
    policy_out = PolicyOutput(
        state_log_flow=torch.tensor([0.0, 0.25], dtype=torch.bfloat16),
        stop_logit=torch.log(torch.tensor([0.25, 0.6], dtype=torch.float32)),
        edge_logit=torch.log(torch.tensor([0.25, 0.5, 0.4], dtype=torch.float32)),
        frontier=Frontier(
            row_ids=torch.tensor([0, 0, 1], dtype=torch.long),
            edge_ids=torch.tensor([0, 1, 2], dtype=torch.long),
            parent_node_ids=torch.tensor([0, 0, 1], dtype=torch.long),
            child_node_ids=torch.tensor([1, 2, 2], dtype=torch.long),
        ),
    )

    log_prob = forward_action_log_prob(
        policy_out=policy_out,
        action_edge_ids=torch.tensor([1, -1], dtype=torch.long),
        num_edges=3,
    )

    assert log_prob.dtype == torch.float32
    assert torch.isfinite(log_prob).all()


def test_state_log_flow_promotes_bf16_policy_outputs_to_float32() -> None:
    policy_out = PolicyOutput(
        state_log_flow=torch.tensor([0.0], dtype=torch.bfloat16),
        stop_logit=torch.tensor([-0.5], dtype=torch.bfloat16),
        edge_logit=torch.tensor([-0.5], dtype=torch.bfloat16),
        frontier=Frontier(
            row_ids=torch.tensor([0], dtype=torch.long),
            edge_ids=torch.tensor([0], dtype=torch.long),
            parent_node_ids=torch.tensor([0], dtype=torch.long),
            child_node_ids=torch.tensor([1], dtype=torch.long),
        ),
    )

    assert state_log_flow(policy_out).dtype == torch.float32


def test_flat_action_probabilities_sum_to_one_per_row() -> None:
    policy_out = PolicyOutput(
        state_log_flow=torch.tensor([-1.0, -2.0], dtype=torch.float32),
        stop_logit=torch.log(torch.tensor([0.25, 0.4], dtype=torch.float32)),
        edge_logit=torch.log(torch.tensor([0.75, 0.6], dtype=torch.float32)),
        frontier=Frontier(
            row_ids=torch.tensor([0, 1], dtype=torch.long),
            edge_ids=torch.tensor([0, 1], dtype=torch.long),
            parent_node_ids=torch.tensor([0, 1], dtype=torch.long),
            child_node_ids=torch.tensor([1, 2], dtype=torch.long),
        ),
    )

    stop_prob = stop_probability(policy_out)
    edge_mass = edge_probability_mass(policy_out)

    assert torch.allclose(stop_prob + edge_mass, torch.ones_like(stop_prob))


def test_edge_probability_mass_is_zero_when_frontier_is_empty() -> None:
    frontier = Frontier(
        row_ids=torch.empty(0, dtype=torch.long),
        edge_ids=torch.empty(0, dtype=torch.long),
        parent_node_ids=torch.empty(0, dtype=torch.long),
        child_node_ids=torch.empty(0, dtype=torch.long),
    )
    policy_out = PolicyOutput(
        state_log_flow=torch.tensor([-1.0, -2.0], dtype=torch.float32),
        stop_logit=torch.zeros(2, dtype=torch.float32),
        edge_logit=torch.empty(0, dtype=torch.float32),
        frontier=frontier,
    )

    assert torch.allclose(edge_probability_mass(policy_out), torch.zeros(2))


def test_subtrajectory_balance_residuals_cover_edge_and_terminal_segments() -> None:
    residuals, source_ids = subtrajectory_balance_residuals(
        parent_flow=torch.tensor([10.0, 20.0, 30.0]),
        child_flow=torch.tensor([11.0, 22.0, 33.0]),
        action_log_prob=torch.tensor([1.0, 2.0, 3.0]),
        log_pb=torch.tensor([-0.5, -0.25, 0.0]),
        log_reward=torch.tensor([0.0, 0.0, 40.0]),
        action_edge_ids=torch.tensor([0, 1, -1], dtype=torch.long),
        trajectory_ids=torch.tensor([0, 0, 0], dtype=torch.long),
        step_ids=torch.tensor([0, 1, 2], dtype=torch.long),
        source_ids=torch.tensor([0, 0, 0], dtype=torch.long),
        max_len=None,
        enabled=True,
    )

    assert torch.equal(source_ids, torch.tensor([0, 0, 0]))
    assert torch.allclose(
        residuals,
        torch.tensor([-8.25, -23.25, -14.75]),
    )
