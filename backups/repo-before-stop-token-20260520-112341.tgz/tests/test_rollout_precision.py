from __future__ import annotations

import torch

from src.weaver.policy import PolicyOutput
from src.weaver.rollout.action import Action, sample_action
from src.weaver.rollout.result import RolloutResult
from src.weaver.rollout.trace import RolloutTrace
from src.weaver.state import Frontier


def test_sample_action_normalizes_bfloat16_policy_outputs_to_float32() -> None:
    policy_out = PolicyOutput(
        state_log_flow=torch.tensor([5.0, 0.0], dtype=torch.bfloat16),
        stop_logit=torch.tensor([-0.1, 0.0], dtype=torch.bfloat16),
        edge_logit=torch.tensor([-2.0], dtype=torch.bfloat16),
        frontier=Frontier(
            row_ids=torch.tensor([0], dtype=torch.long),
            edge_ids=torch.tensor([0], dtype=torch.long),
            parent_node_ids=torch.tensor([0], dtype=torch.long),
            child_node_ids=torch.tensor([1], dtype=torch.long),
        ),
    )

    action = sample_action(
        policy_out=policy_out,
        frontier=policy_out.frontier,
    )

    assert action.stop_log_prob.dtype == torch.float32
    assert action.expand_log_prob.dtype == torch.float32


def test_sample_action_forces_stop_when_frontier_is_empty() -> None:
    frontier = Frontier(
        row_ids=torch.empty(0, dtype=torch.long),
        edge_ids=torch.empty(0, dtype=torch.long),
        parent_node_ids=torch.empty(0, dtype=torch.long),
        child_node_ids=torch.empty(0, dtype=torch.long),
    )
    policy_out = PolicyOutput(
        state_log_flow=torch.tensor([0.0], dtype=torch.bfloat16),
        stop_logit=torch.tensor([0.0], dtype=torch.bfloat16),
        edge_logit=torch.empty(0, dtype=torch.bfloat16),
        frontier=frontier,
    )

    action = sample_action(
        policy_out=policy_out,
        frontier=frontier,
    )

    assert action.stop_rows.tolist() == [0]
    assert action.forced_stop.tolist() == [True]
    assert action.stop_log_prob.dtype == torch.float32
    assert action.expand_log_prob.dtype == torch.float32


def test_sample_action_records_untempered_log_prob() -> None:
    frontier = Frontier(
        row_ids=torch.tensor([0], dtype=torch.long),
        edge_ids=torch.tensor([7], dtype=torch.long),
        parent_node_ids=torch.tensor([0], dtype=torch.long),
        child_node_ids=torch.tensor([1], dtype=torch.long),
    )
    policy_out = PolicyOutput(
        state_log_flow=torch.tensor([0.0], dtype=torch.float32),
        stop_logit=torch.tensor([0.0], dtype=torch.float32),
        edge_logit=torch.tensor([0.0], dtype=torch.float32),
        frontier=frontier,
    )

    action = sample_action(
        policy_out=policy_out,
        frontier=frontier,
        temperature=0.05,
    )

    recorded = (
        action.stop_log_prob
        if action.stop_rows.numel() > 0
        else action.expand_log_prob
    )
    assert torch.allclose(recorded, torch.full((1,), -torch.log(torch.tensor(2.0))))


def test_rollout_trace_records_bfloat16_action_log_prob_as_float32() -> None:
    trace = RolloutTrace(
        R=3,
        T=1,
        device=torch.device("cpu"),
    )
    action = Action(
        stop_rows=torch.tensor([0, 1], dtype=torch.long),
        stop_log_prob=torch.tensor([-0.5, -1.5], dtype=torch.bfloat16),
        forced_stop=torch.tensor([False, True], dtype=torch.bool),
        expand_rows=torch.empty(0, dtype=torch.long),
        edge_ids=torch.empty(0, dtype=torch.long),
        expand_log_prob=torch.empty(0, dtype=torch.bfloat16),
    )

    trace.write_action(
        t=0,
        active_rows=torch.tensor([2, 0], dtype=torch.long),
        action=action,
    )

    assert trace.terminal_log_prob.dtype == torch.float32
    assert torch.allclose(
        trace.terminal_log_prob,
        torch.tensor([-1.5, 0.0, -0.5], dtype=torch.float32),
    )


def test_rollout_result_from_trace_derives_valid_mask_and_action_type() -> None:
    trace = RolloutTrace(
        R=2,
        T=2,
        device=torch.device("cpu"),
    )
    trace.write_action(
        t=0,
        active_rows=torch.tensor([0, 1], dtype=torch.long),
        action=Action(
            stop_rows=torch.tensor([1], dtype=torch.long),
            stop_log_prob=torch.tensor([-0.5]),
            forced_stop=torch.tensor([False], dtype=torch.bool),
            expand_rows=torch.tensor([0], dtype=torch.long),
            edge_ids=torch.tensor([3], dtype=torch.long),
            expand_log_prob=torch.tensor([-0.2]),
        ),
    )

    result = RolloutResult.from_trace(
        trace=trace,
        source_graph_id=torch.tensor([0, 0], dtype=torch.long),
        expand_budget=1,
    )

    assert result.valid_mask.tolist() == [[True, False], [True, False]]
    assert result.action_type.tolist() == [[1, 0], [2, 0]]
    assert result.selected_edge_ids.tolist() == [[3, -1], [-1, -1]]
