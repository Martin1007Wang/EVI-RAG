from __future__ import annotations

import torch

from src.data.collate import RetrievalCollator
from src.data.dataset import _build_retrieval_data
from src.data.schema.fields import SampleFields
from src.weaver.context import GraphContext
from src.weaver.loss import edge_probability_mass, state_log_flow, stop_probability
from src.weaver.policy import Policy, PolicyOutput
from src.weaver.rollout.action import sample_action
from src.weaver.rollout.engine import RolloutEngine
from src.weaver.state import Frontier, State


def test_flat_policy_probabilities_are_jointly_normalized() -> None:
    policy_out = PolicyOutput(
        state_log_flow=torch.tensor([1.0, 0.5], dtype=torch.float32),
        stop_logit=torch.log(torch.tensor([0.2, 0.7], dtype=torch.float32)),
        edge_logit=torch.log(torch.tensor([0.3, 0.5, 0.3], dtype=torch.float32)),
        frontier=Frontier(
            row_ids=torch.tensor([0, 0, 1], dtype=torch.long),
            edge_ids=torch.tensor([4, 5, 6], dtype=torch.long),
            parent_node_ids=torch.tensor([0, 0, 1], dtype=torch.long),
            child_node_ids=torch.tensor([1, 2, 2], dtype=torch.long),
        ),
    )

    stop_prob = stop_probability(policy_out)
    edge_mass = edge_probability_mass(policy_out)

    assert torch.allclose(stop_prob + edge_mass, torch.ones_like(stop_prob), atol=1e-5)
    assert torch.allclose(state_log_flow(policy_out), policy_out.state_log_flow)


def test_sample_action_forces_stop_on_dead_end_rows() -> None:
    frontier = Frontier(
        row_ids=torch.tensor([1], dtype=torch.long),
        edge_ids=torch.tensor([7], dtype=torch.long),
        parent_node_ids=torch.tensor([0], dtype=torch.long),
        child_node_ids=torch.tensor([1], dtype=torch.long),
    )
    policy_out = PolicyOutput(
        state_log_flow=torch.zeros(2, dtype=torch.float32),
        stop_logit=torch.tensor([0.0, -5.0], dtype=torch.float32),
        edge_logit=torch.tensor([0.0], dtype=torch.float32),
        frontier=frontier,
    )

    action = sample_action(
        policy_out=policy_out,
        frontier=frontier,
    )

    assert 0 in action.stop_rows.tolist()
    forced_by_row = dict(zip(action.stop_rows.tolist(), action.forced_stop.tolist(), strict=True))
    assert forced_by_row[0] is True


def test_policy_empty_frontier_returns_terminal_only_flow() -> None:
    frontier = Frontier(
        row_ids=torch.empty(0, dtype=torch.long),
        edge_ids=torch.empty(0, dtype=torch.long),
        parent_node_ids=torch.empty(0, dtype=torch.long),
        child_node_ids=torch.empty(0, dtype=torch.long),
    )
    out = PolicyOutput(
        state_log_flow=torch.tensor([0.3, -0.2], dtype=torch.float32),
        stop_logit=torch.zeros(2, dtype=torch.float32),
        edge_logit=torch.empty(0, dtype=torch.float32),
        frontier=frontier,
    )

    assert out.edge_logit.numel() == 0
    assert torch.allclose(state_log_flow(out), out.state_log_flow)
    assert torch.allclose(stop_probability(out), torch.ones_like(out.state_log_flow))


def test_rollout_engine_produces_terminal_rows_with_flat_actions() -> None:
    batch = _batch()
    context = GraphContext.from_batch(batch)
    engine = RolloutEngine(expand_budget=1)
    rollouts = engine.sample_rollouts(
        policy=_AllStopPolicy(),
        context=context,
        features=_features(),
        num_rollouts=1,
        temperature=1.0,
    )

    assert len(rollouts) == 1
    rollout = rollouts[0]
    assert rollout.terminal_mask.any().item() is True
    assert rollout.expand_mask.any().item() is False


class _AllStopPolicy(Policy):
    def __init__(self) -> None:
        pass

    def __call__(self, *, features, state: State, context: GraphContext, frontier: Frontier):
        del features, context
        return PolicyOutput(
            state_log_flow=torch.zeros(state.num_rows),
            stop_logit=torch.zeros(state.num_rows),
            edge_logit=torch.full((frontier.num_actions,), -100.0),
            frontier=frontier,
        )


def _features():
    return type("Features", (), {})()


def _batch():
    data = _build_retrieval_data(
        raw={
            SampleFields.EDGE_INDEX: torch.tensor(
                [[0, 1], [1, 2]],
                dtype=torch.long,
            ),
            SampleFields.NODE_ENTITY_CATALOG_IDS: torch.tensor([0, 1, 2], dtype=torch.long),
            SampleFields.EDGE_RELATION_CATALOG_IDS: torch.tensor([0, 1], dtype=torch.long),
            SampleFields.NUM_NODES: torch.tensor(3, dtype=torch.long),
            SampleFields.NUM_EDGES: torch.tensor(2, dtype=torch.long),
            SampleFields.ANCHOR_NODE_IDS: torch.tensor([0], dtype=torch.long),
            SampleFields.TARGET_NODE_IDS: torch.tensor([2], dtype=torch.long),
            SampleFields.REACHABLE_TARGET_NODE_IDS: torch.tensor([2], dtype=torch.long),
            SampleFields.ANCHOR_NODE_FORWARD_DISTANCE_FLAT: torch.tensor([0, 1, 2], dtype=torch.long),
            SampleFields.ANCHOR_NODE_BACKWARD_DISTANCE_FLAT: torch.tensor([0, -1, -1], dtype=torch.long),
            SampleFields.NODE_TARGET_DISTANCE: torch.tensor([2, 1, 0], dtype=torch.long),
            SampleFields.NODE_TARGET_DISTANCES_FLAT: torch.tensor([2, 1, 0], dtype=torch.long),
            SampleFields.NODE_TARGET_SHORTEST_PATH_COUNT_FLAT: torch.ones(3, dtype=torch.float32),
            SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_INDICES: torch.tensor([0, 1], dtype=torch.long),
            SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_VALUES: torch.ones(2, dtype=torch.float32),
        },
        sample_id="canonical-flat-flow",
        question_emb=torch.tensor([1.0, 0.0], dtype=torch.float32),
    )
    return RetrievalCollator()([data])
