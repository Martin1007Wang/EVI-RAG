from __future__ import annotations

import torch

from src.data.collate import RetrievalCollator
from src.data.dataset import _build_retrieval_data
from src.data.schema.fields import SampleFields
from src.weaver.context import GraphContext
from src.weaver.rollout.replay import ReplaySource, replay_trajectories
from src.weaver.rollout.result import RolloutResult


def test_replay_source_marks_final_answer_transition_terminal() -> None:
    batch = _batch()
    context = GraphContext.from_batch(batch)

    replay = ReplaySource(expand_budget=2).sample_from_rollouts(
        batch=batch,
        context=context,
        rollouts=(),
        num_transitions=1,
    )

    assert replay is not None
    assert replay.num_trajectories == 1
    assert torch.equal(replay.transitions.action_edge_ids, torch.tensor([0, 1, -1]))
    assert torch.equal(replay.transitions.trajectory_ids, torch.tensor([0, 0, 0]))
    assert torch.equal(replay.transitions.step_ids, torch.tensor([0, 1, 2]))
    assert torch.equal(replay.transitions.is_terminal, torch.tensor([False, False, True]))
    assert bool(replay.transitions.child_state.node_mask[-1, 2])


def test_replay_focuses_graphs_not_hit_by_policy_rollouts() -> None:
    batch = _batch()
    context = GraphContext.from_batch(batch)

    missed = replay_trajectories(
        batch=batch,
        context=context,
        rollouts=(_rollout(edge_ids=(0,), terminal_step=1, budget=2),),
        budget=2,
        max_trajectories=1,
    )
    hit = replay_trajectories(
        batch=batch,
        context=context,
        rollouts=(_rollout(edge_ids=(0, 1), terminal_step=2, budget=2),),
        budget=2,
        max_trajectories=1,
    )

    assert [trajectory.edge_ids for trajectory in missed] == [(0, 1)]
    assert hit == []


def test_replay_uses_precomputed_shortest_path_labels_without_bfs() -> None:
    batch = _batch_with_branching_shortest_paths()
    context = GraphContext.from_batch(batch)

    trajectories = replay_trajectories(
        batch=batch,
        context=context,
        rollouts=(),
        budget=2,
        max_trajectories=1,
    )

    assert [trajectory.edge_ids for trajectory in trajectories] == [(0, 2)]


def test_replay_prefers_nearest_anchor_under_precomputed_labels() -> None:
    batch = _batch_with_multiple_anchors()
    context = GraphContext.from_batch(batch)

    trajectories = replay_trajectories(
        batch=batch,
        context=context,
        rollouts=(),
        budget=2,
        max_trajectories=1,
    )

    assert [trajectory.edge_ids for trajectory in trajectories] == [(2,)]


def _batch():
    raw = {
        SampleFields.EDGE_INDEX: torch.tensor([[0, 1], [1, 2]], dtype=torch.long),
        SampleFields.NODE_ENTITY_CATALOG_IDS: torch.tensor([10, 11, 12], dtype=torch.long),
        SampleFields.EDGE_RELATION_CATALOG_IDS: torch.tensor([20, 21], dtype=torch.long),
        SampleFields.NUM_NODES: torch.tensor(3, dtype=torch.long),
        SampleFields.NUM_EDGES: torch.tensor(2, dtype=torch.long),
        SampleFields.ANCHOR_NODE_IDS: torch.tensor([0], dtype=torch.long),
        SampleFields.TARGET_NODE_IDS: torch.tensor([2], dtype=torch.long),
        SampleFields.REACHABLE_TARGET_NODE_IDS: torch.tensor([2], dtype=torch.long),
        SampleFields.ANCHOR_NODE_FORWARD_DISTANCE_FLAT: torch.tensor([0, 1, 2], dtype=torch.long),
        SampleFields.ANCHOR_NODE_BACKWARD_DISTANCE_FLAT: torch.tensor([0, -1, -1], dtype=torch.long),
        SampleFields.NODE_TARGET_DISTANCE: torch.tensor([2, 1, 0], dtype=torch.long),
        SampleFields.NODE_TARGET_DISTANCES_FLAT: torch.tensor([2, 1, 0], dtype=torch.long),
        SampleFields.NODE_TARGET_SHORTEST_PATH_COUNT_FLAT: torch.tensor([1.0, 1.0, 1.0], dtype=torch.float32),
        SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_INDICES: torch.tensor([0, 1], dtype=torch.long),
        SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_VALUES: torch.tensor([1.0, 1.0], dtype=torch.float32),
    }
    data = _build_retrieval_data(
        raw=raw,
        sample_id="sample-0",
        question_emb=torch.tensor([0.0, 1.0], dtype=torch.float32),
    )
    return RetrievalCollator()([data])


def _rollout(
    *,
    edge_ids: tuple[int, ...],
    terminal_step: int,
    budget: int,
) -> RolloutResult:
    max_steps = int(budget) + 1
    selected_edge_ids = torch.full((1, max_steps), -1, dtype=torch.long)
    expand_mask = torch.zeros((1, max_steps), dtype=torch.bool)
    terminal_mask = torch.zeros((1, max_steps), dtype=torch.bool)
    action_type = torch.zeros((1, max_steps), dtype=torch.long)

    for step, edge_id in enumerate(edge_ids):
        selected_edge_ids[0, step] = int(edge_id)
        expand_mask[0, step] = True
        action_type[0, step] = 1

    terminal_mask[0, terminal_step] = True
    action_type[0, terminal_step] = 2

    return RolloutResult(
        source_graph_id=torch.tensor([0], dtype=torch.long),
        traj_len=torch.tensor([terminal_step + 1], dtype=torch.long),
        terminal_step=torch.tensor([terminal_step], dtype=torch.long),
        terminal_log_prob=torch.zeros(1, dtype=torch.float32),
        valid_mask=expand_mask | terminal_mask,
        expand_mask=expand_mask,
        terminal_mask=terminal_mask,
        forced_terminal_mask=torch.zeros((1, max_steps), dtype=torch.bool),
        action_type=action_type,
        selected_edge_ids=selected_edge_ids,
        expand_budget=budget,
    )


def _batch_with_branching_shortest_paths():
    raw = {
        SampleFields.EDGE_INDEX: torch.tensor(
            [[0, 0, 1, 2], [1, 2, 3, 3]],
            dtype=torch.long,
        ),
        SampleFields.NODE_ENTITY_CATALOG_IDS: torch.tensor([10, 11, 12, 13], dtype=torch.long),
        SampleFields.EDGE_RELATION_CATALOG_IDS: torch.tensor([20, 21, 22, 23], dtype=torch.long),
        SampleFields.NUM_NODES: torch.tensor(4, dtype=torch.long),
        SampleFields.NUM_EDGES: torch.tensor(4, dtype=torch.long),
        SampleFields.ANCHOR_NODE_IDS: torch.tensor([0], dtype=torch.long),
        SampleFields.TARGET_NODE_IDS: torch.tensor([3], dtype=torch.long),
        SampleFields.REACHABLE_TARGET_NODE_IDS: torch.tensor([3], dtype=torch.long),
        SampleFields.ANCHOR_NODE_FORWARD_DISTANCE_FLAT: torch.tensor([0, 1, 1, 2], dtype=torch.long),
        SampleFields.ANCHOR_NODE_BACKWARD_DISTANCE_FLAT: torch.tensor([0, -1, -1, -1], dtype=torch.long),
        SampleFields.NODE_TARGET_DISTANCE: torch.tensor([2, 1, 1, 0], dtype=torch.long),
        SampleFields.NODE_TARGET_DISTANCES_FLAT: torch.tensor([2, 1, 1, 0], dtype=torch.long),
        SampleFields.NODE_TARGET_SHORTEST_PATH_COUNT_FLAT: torch.tensor(
            [2.0, 1.0, 1.0, 1.0],
            dtype=torch.float32,
        ),
        SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_INDICES: torch.tensor(
            [0, 1, 2, 3],
            dtype=torch.long,
        ),
        SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_VALUES: torch.tensor(
            [2.0, 1.0, 2.0, 1.0],
            dtype=torch.float32,
        ),
    }
    data = _build_retrieval_data(
        raw=raw,
        sample_id="sample-branching",
        question_emb=torch.tensor([0.0, 1.0], dtype=torch.float32),
    )
    return RetrievalCollator()([data])


def _batch_with_multiple_anchors():
    raw = {
        SampleFields.EDGE_INDEX: torch.tensor(
            [[0, 1, 2], [1, 3, 3]],
            dtype=torch.long,
        ),
        SampleFields.NODE_ENTITY_CATALOG_IDS: torch.tensor([10, 11, 12, 13], dtype=torch.long),
        SampleFields.EDGE_RELATION_CATALOG_IDS: torch.tensor([20, 21, 22], dtype=torch.long),
        SampleFields.NUM_NODES: torch.tensor(4, dtype=torch.long),
        SampleFields.NUM_EDGES: torch.tensor(3, dtype=torch.long),
        SampleFields.ANCHOR_NODE_IDS: torch.tensor([0, 2], dtype=torch.long),
        SampleFields.TARGET_NODE_IDS: torch.tensor([3], dtype=torch.long),
        SampleFields.REACHABLE_TARGET_NODE_IDS: torch.tensor([3], dtype=torch.long),
        SampleFields.ANCHOR_NODE_FORWARD_DISTANCE_FLAT: torch.tensor([0, 1, 0, 1], dtype=torch.long),
        SampleFields.ANCHOR_NODE_BACKWARD_DISTANCE_FLAT: torch.tensor([0, -1, 0, -1], dtype=torch.long),
        SampleFields.NODE_TARGET_DISTANCE: torch.tensor([2, 1, 1, 0], dtype=torch.long),
        SampleFields.NODE_TARGET_DISTANCES_FLAT: torch.tensor([2, 1, 1, 0], dtype=torch.long),
        SampleFields.NODE_TARGET_SHORTEST_PATH_COUNT_FLAT: torch.tensor(
            [1.0, 1.0, 1.0, 1.0],
            dtype=torch.float32,
        ),
        SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_INDICES: torch.tensor(
            [0, 1, 2],
            dtype=torch.long,
        ),
        SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_VALUES: torch.tensor(
            [1.0, 1.0, 1.0],
            dtype=torch.float32,
        ),
    }
    data = _build_retrieval_data(
        raw=raw,
        sample_id="sample-multi-anchor",
        question_emb=torch.tensor([0.0, 1.0], dtype=torch.float32),
    )
    return RetrievalCollator()([data])
