from __future__ import annotations

import torch

from src.weaver.loss import source_rollout_metrics
from src.weaver.state import Frontier, State
from src.weaver.transitions import (
    TRANSITION_SOURCE_POLICY,
    TRANSITION_SOURCE_REPLAY,
    TransitionBatch,
)


def test_concat_reindex_keeps_policy_and_replay_trajectories_distinct() -> None:
    policy = _transition_batch(
        trajectory_ids=torch.tensor([0, 0, 1]),
        action_edge_ids=torch.tensor([0, -1, -1]),
    ).with_source_id(TRANSITION_SOURCE_POLICY)
    replay = _transition_batch(
        trajectory_ids=torch.tensor([0, 0]),
        action_edge_ids=torch.tensor([0, -1]),
    ).with_source_id(TRANSITION_SOURCE_REPLAY)

    out = TransitionBatch.concat_reindex_trajectories([policy, replay])

    assert torch.equal(out.trajectory_ids, torch.tensor([0, 0, 1, 2, 2]))
    assert torch.equal(
        out.source_ids,
        torch.tensor(
            [
                TRANSITION_SOURCE_POLICY,
                TRANSITION_SOURCE_POLICY,
                TRANSITION_SOURCE_POLICY,
                TRANSITION_SOURCE_REPLAY,
                TRANSITION_SOURCE_REPLAY,
            ]
        ),
    )


def test_source_rollout_metrics_split_policy_stop_and_forced_stop() -> None:
    metrics = source_rollout_metrics(
        source_ids=torch.tensor(
            [
                TRANSITION_SOURCE_POLICY,
                TRANSITION_SOURCE_POLICY,
                TRANSITION_SOURCE_REPLAY,
                TRANSITION_SOURCE_POLICY,
            ]
        ),
        action_edge_ids=torch.tensor([0, -1, -1, -1]),
        step_ids=torch.tensor([0, 1, 1, 2]),
        parent_frontier=Frontier(
            row_ids=torch.tensor([0], dtype=torch.long),
            edge_ids=torch.tensor([0], dtype=torch.long),
            parent_node_ids=torch.tensor([0], dtype=torch.long),
            child_node_ids=torch.tensor([1], dtype=torch.long),
        ),
        num_rows=4,
    )

    assert torch.isclose(metrics["rollout/stop_rate"], torch.tensor(2.0 / 3.0))
    assert torch.isclose(metrics["rollout/forced_stop_rate"], torch.tensor(1.0))
    assert torch.isclose(metrics["rollout/mean_depth"], torch.tensor(1.5))


def _transition_batch(
    *,
    trajectory_ids: torch.Tensor,
    action_edge_ids: torch.Tensor,
) -> TransitionBatch:
    num_rows = int(action_edge_ids.numel())
    state = State(
        node_mask=torch.zeros((num_rows, 1), dtype=torch.bool),
        edge_mask=torch.zeros((num_rows, 1), dtype=torch.bool),
        max_budget_by_row=torch.ones(num_rows, dtype=torch.long),
        row_to_graph=torch.zeros(num_rows, dtype=torch.long),
    )
    return TransitionBatch(
        parent_state=state,
        child_state=state.clone(),
        trajectory_ids=trajectory_ids,
        step_ids=torch.arange(num_rows, dtype=torch.long),
        action_edge_ids=action_edge_ids,
    )
