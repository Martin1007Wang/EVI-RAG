from __future__ import annotations

import torch

from src.data.collate import RetrievalCollator
from src.data.dataset import _build_retrieval_data
from src.data.schema.fields import SampleFields
from src.weaver.context import GraphContext
from src.weaver.loss import LossOutput, StateFlowPolicyDBLoss
from src.weaver.nn.feature_encoder import FeatureEncoder
from src.weaver.policy import PolicyOutput
from src.weaver.reward import Reward
from src.weaver.state import State
from src.weaver.transitions import TransitionBatch


def test_reward_output_is_non_differentiable() -> None:
    batch = _batch()
    context = GraphContext.from_batch(batch)
    reward = Reward()
    reward_context = reward.prepare_context(batch, expand_budget=2)

    state = State.initial(
        context=context,
        budget=2,
        rollouts_per_graph=1,
    )
    state.apply_edges_(
        context=context,
        row_ids=torch.tensor([0], dtype=torch.long),
        edge_ids=torch.tensor([0], dtype=torch.long),
    )

    output = reward(
        state=state,
        context=reward_context,
    )

    assert torch.allclose(output.answer_recall, torch.tensor([1.0]))
    assert not output.log_reward.requires_grad


def test_state_flow_loss_calls_reward_model_for_visited_parent_states() -> None:
    batch = _batch()
    features = FeatureEncoder(
        entity_text_semantic_table=torch.eye(3, 2, dtype=torch.float32),
        text_row_by_entity_id=torch.tensor([0, 1, 2], dtype=torch.long),
        relation_semantic_table=torch.eye(2, 2, dtype=torch.float32),
        model_dim=2,
    )(batch)
    context = GraphContext.from_batch(batch)

    parent = State.initial(
        context=context,
        budget=2,
        rollouts_per_graph=1,
    )
    child = parent.clone()
    child.apply_edges_(
        context=context,
        row_ids=torch.tensor([0], dtype=torch.long),
        edge_ids=torch.tensor([0], dtype=torch.long),
    )

    reward = _RecordingReward()
    output = StateFlowPolicyDBLoss()(
        policy=_ConstantPolicy(),
        reward_model=reward,
        transitions=TransitionBatch(
            parent_state=parent,
            child_state=child,
            action_edge_ids=torch.tensor([0], dtype=torch.long),
            source_ids=torch.tensor([0], dtype=torch.long),
        ),
        context=context,
        reward_context=reward.prepare_context(batch, expand_budget=2),
        features=features,
    )

    assert isinstance(output, LossOutput)
    assert reward.seen_state_rows == [1]


class _RecordingReward(Reward):
    def __init__(self) -> None:
        super().__init__()
        self.seen_state_rows: list[int] = []

    def forward(self, *, state: State, context):
        self.seen_state_rows.append(int(state.num_rows))
        return super().forward(state=state, context=context)


class _ConstantPolicy:
    def __call__(self, *, state: State, frontier, **kwargs) -> PolicyOutput:
        del kwargs
        return PolicyOutput(
            state_log_flow=torch.zeros(state.num_rollouts),
            stop_logit=torch.zeros(state.num_rollouts),
            edge_logit=torch.zeros(frontier.num_actions),
            frontier=frontier,
        )


def _batch():
    data = _build_retrieval_data(
        raw={
            SampleFields.EDGE_INDEX: torch.tensor(
                [[0, 0], [1, 2]],
                dtype=torch.long,
            ),
            SampleFields.NODE_ENTITY_CATALOG_IDS: torch.tensor(
                [0, 1, 2],
                dtype=torch.long,
            ),
            SampleFields.EDGE_RELATION_CATALOG_IDS: torch.tensor(
                [0, 1],
                dtype=torch.long,
            ),
            SampleFields.NUM_NODES: torch.tensor(3, dtype=torch.long),
            SampleFields.NUM_EDGES: torch.tensor(2, dtype=torch.long),
            SampleFields.ANCHOR_NODE_IDS: torch.tensor([0], dtype=torch.long),
            SampleFields.TARGET_NODE_IDS: torch.tensor([1], dtype=torch.long),
            SampleFields.REACHABLE_TARGET_NODE_IDS: torch.tensor([1], dtype=torch.long),
            SampleFields.ANCHOR_NODE_FORWARD_DISTANCE_FLAT: torch.tensor(
                [0, 1, 1],
                dtype=torch.long,
            ),
            SampleFields.ANCHOR_NODE_BACKWARD_DISTANCE_FLAT: torch.tensor(
                [0, -1, -1],
                dtype=torch.long,
            ),
            SampleFields.NODE_TARGET_DISTANCE: torch.tensor(
                [1, 0, 1],
                dtype=torch.long,
            ),
            SampleFields.NODE_TARGET_DISTANCES_FLAT: torch.tensor(
                [1, 0, 1],
                dtype=torch.long,
            ),
            SampleFields.NODE_TARGET_SHORTEST_PATH_COUNT_FLAT: torch.ones(
                3,
                dtype=torch.float32,
            ),
            SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_INDICES: torch.tensor(
                [0],
                dtype=torch.long,
            ),
            SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_VALUES: torch.ones(
                1,
                dtype=torch.float32,
            ),
        },
        sample_id="reward-utility",
        question_emb=torch.tensor([1.0, 0.0], dtype=torch.float32),
    )
    return RetrievalCollator()([data])
