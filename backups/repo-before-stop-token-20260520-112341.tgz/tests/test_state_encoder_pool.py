from __future__ import annotations

import torch

from src.weaver.nn.state_encoder import SegmentTokenPool


def test_segment_token_pool_mean_pools_by_row() -> None:
    pool = SegmentTokenPool(input_dim=1, output_dim=1)
    pool.token_proj = torch.nn.Identity()

    out = pool(
        tokens=torch.tensor([[2.0], [4.0], [10.0]]),
        row_ids=torch.tensor([0, 0, 1], dtype=torch.long),
        num_rows=3,
    )

    assert torch.allclose(
        out,
        torch.tensor([[3.0], [10.0], [0.0]]),
    )
