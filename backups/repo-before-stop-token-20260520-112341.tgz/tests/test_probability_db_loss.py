from __future__ import annotations

import torch

from src.data.collate import RetrievalCollator
from src.data.dataset import _build_retrieval_data
from src.data.schema.fields import SampleFields
from src.weaver.context import GraphContext
from src.weaver.loss import StateFlowPolicyDBLoss, residual_loss_units
from src.weaver.nn.feature_encoder import FeatureEncoder
from src.weaver.policy import PolicyOutput
from src.weaver.reward import Reward
from src.weaver.state import State
from src.weaver.transitions import TRANSITION_SOURCE_POLICY, TransitionBatch


def test_huber_residual_loss_units_match_piecewise_definition() -> None:
    residuals = torch.tensor([-3.0, -1.0, 0.0, 1.0, 3.0], dtype=torch.float32)

    out = residual_loss_units(
        residuals,
        loss_type="huber",
        huber_delta=2.0,
    )

    expected = torch.tensor([4.0, 0.5, 0.0, 0.5, 4.0], dtype=torch.float32)
    assert torch.allclose(out, expected)


def test_mse_residual_loss_units_square_residuals() -> None:
    residuals = torch.tensor([-2.0, 0.5], dtype=torch.float32)

    out = residual_loss_units(
        residuals,
        loss_type="mse",
        huber_delta=2.0,
    )

    assert torch.allclose(out, torch.tensor([4.0, 0.25], dtype=torch.float32))


def test_db_edge_residual_uses_state_flow_plus_forward_policy() -> None:
    batch = _single_edge_batch()
    context = GraphContext.from_batch(batch)
    features = FeatureEncoder(
        entity_text_semantic_table=torch.eye(2, dtype=torch.float32),
        text_row_by_entity_id=torch.arange(2, dtype=torch.long),
        relation_semantic_table=torch.ones((1, 2), dtype=torch.float32),
        model_dim=2,
    )(batch)

    parent = State.initial(
        context=context,
        budget=1,
        rollouts_per_graph=1,
    )
    child = parent.clone()
    child.apply_edges_(
        context=context,
        row_ids=torch.tensor([0], dtype=torch.long),
        edge_ids=torch.tensor([0], dtype=torch.long),
    )

    output = StateFlowPolicyDBLoss(
        lambda_stop=0.0,
        lambda_subtb=0.0,
        residual_loss="mse",
    )(
        policy=_FixedDBPolicy(),
        reward_model=Reward(),
        transitions=TransitionBatch(
            parent_state=parent,
            child_state=child,
            action_edge_ids=torch.tensor([0], dtype=torch.long),
            source_ids=torch.tensor([TRANSITION_SOURCE_POLICY], dtype=torch.long),
        ),
        context=context,
        reward_context=Reward().prepare_context(batch, expand_budget=1),
        features=features,
    )

    # parent logF + parent logPF(edge) - child logF - logPB
    # = 2.0 - 0.3 - 0.7 - 0.0 = 1.0
    assert torch.allclose(output.loss, torch.tensor(1.0))


def test_stop_db_supervises_edge_only_visited_parent_states() -> None:
    batch = _single_edge_batch()
    context = GraphContext.from_batch(batch)
    features = FeatureEncoder(
        entity_text_semantic_table=torch.eye(2, dtype=torch.float32),
        text_row_by_entity_id=torch.arange(2, dtype=torch.long),
        relation_semantic_table=torch.ones((1, 2), dtype=torch.float32),
        model_dim=2,
    )(batch)

    parent = State.initial(
        context=context,
        budget=1,
        rollouts_per_graph=1,
    )
    child = parent.clone()
    child.apply_edges_(
        context=context,
        row_ids=torch.tensor([0], dtype=torch.long),
        edge_ids=torch.tensor([0], dtype=torch.long),
    )
    transitions = TransitionBatch(
        parent_state=parent,
        child_state=child,
        action_edge_ids=torch.tensor([0], dtype=torch.long),
        source_ids=torch.tensor([TRANSITION_SOURCE_POLICY], dtype=torch.long),
    )

    edge_only = StateFlowPolicyDBLoss(
        lambda_stop=0.0,
        lambda_subtb=0.0,
        residual_loss="mse",
    )(
        policy=_FixedDBPolicy(),
        reward_model=Reward(),
        transitions=transitions,
        context=context,
        reward_context=Reward().prepare_context(batch, expand_budget=1),
        features=features,
    )
    with_stop = StateFlowPolicyDBLoss(
        lambda_stop=1.0,
        lambda_subtb=0.0,
        residual_loss="mse",
    )(
        policy=_FixedDBPolicy(),
        reward_model=Reward(),
        transitions=transitions,
        context=context,
        reward_context=Reward().prepare_context(batch, expand_budget=1),
        features=features,
    )

    assert torch.allclose(edge_only.loss, torch.tensor(1.0))
    assert with_stop.metrics["loss/stop_db"].gt(0.0)
    assert with_stop.loss.gt(edge_only.loss)


class _FixedDBPolicy:
    def __call__(self, *, state: State, frontier, **kwargs) -> PolicyOutput:
        del kwargs
        selected_edges = state.edge_mask.long().sum(dim=1)
        is_child = selected_edges.gt(0)
        return PolicyOutput(
            state_log_flow=torch.where(
                is_child,
                torch.full((state.num_rows,), 0.7),
                torch.full((state.num_rows,), 2.0),
            ),
            stop_logit=torch.full(
                (state.num_rows,),
                torch.expm1(torch.tensor(0.3)).log().item(),
            ),
            edge_logit=torch.zeros(frontier.num_actions),
            frontier=frontier,
        )


def _single_edge_batch():
    data = _build_retrieval_data(
        raw={
            SampleFields.EDGE_INDEX: torch.tensor([[0], [1]], dtype=torch.long),
            SampleFields.NODE_ENTITY_CATALOG_IDS: torch.tensor([0, 1], dtype=torch.long),
            SampleFields.EDGE_RELATION_CATALOG_IDS: torch.tensor([0], dtype=torch.long),
            SampleFields.NUM_NODES: torch.tensor(2, dtype=torch.long),
            SampleFields.NUM_EDGES: torch.tensor(1, dtype=torch.long),
            SampleFields.ANCHOR_NODE_IDS: torch.tensor([0], dtype=torch.long),
            SampleFields.TARGET_NODE_IDS: torch.tensor([1], dtype=torch.long),
            SampleFields.REACHABLE_TARGET_NODE_IDS: torch.tensor([1], dtype=torch.long),
            SampleFields.ANCHOR_NODE_FORWARD_DISTANCE_FLAT: torch.tensor([0, 1], dtype=torch.long),
            SampleFields.ANCHOR_NODE_BACKWARD_DISTANCE_FLAT: torch.tensor([0, -1], dtype=torch.long),
            SampleFields.NODE_TARGET_DISTANCE: torch.tensor([1, 0], dtype=torch.long),
            SampleFields.NODE_TARGET_DISTANCES_FLAT: torch.tensor([1, 0], dtype=torch.long),
            SampleFields.NODE_TARGET_SHORTEST_PATH_COUNT_FLAT: torch.ones(2, dtype=torch.float32),
            SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_INDICES: torch.tensor([0], dtype=torch.long),
            SampleFields.NODE_TARGET_SHORTEST_PATH_EDGE_COUNT_VALUES: torch.ones(1, dtype=torch.float32),
        },
        sample_id="single-edge",
        question_emb=torch.tensor([1.0, 0.0], dtype=torch.float32),
    )
    return RetrievalCollator()([data])
