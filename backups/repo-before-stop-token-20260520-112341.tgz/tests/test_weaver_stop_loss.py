from __future__ import annotations

import torch

from src.weaver.context import GraphContext, build_outgoing_index
from src.weaver.loss import UniformLeafBackwardPolicy, backward_action_log_prob, selected_leaf_edge_count
from src.weaver.state import State


def test_uniform_leaf_backward_log_prob_counts_removable_leaf_edges() -> None:
    context = _graph_context()
    state = State(
        node_mask=torch.ones((2, 4), dtype=torch.bool),
        edge_mask=torch.tensor(
            [
                [True, False, True],
                [True, True, False],
            ],
            dtype=torch.bool,
        ),
        max_budget_by_row=torch.full((2,), 3, dtype=torch.long),
        row_to_graph=torch.zeros(2, dtype=torch.long),
    )

    assert selected_leaf_edge_count(
        state=state,
        context=context,
    ).tolist() == [1, 2]

    backward = UniformLeafBackwardPolicy()
    assert torch.allclose(
        backward.log_prob(
            state=state,
            context=context,
        ),
        torch.tensor([0.0, -torch.log(torch.tensor(2.0))]),
    )


def test_backward_action_log_prob_is_zero_for_stop_and_leaf_based_for_edges() -> None:
    context = _graph_context()
    state = State(
        node_mask=torch.ones((2, 4), dtype=torch.bool),
        edge_mask=torch.tensor(
            [
                [True, False, True],
                [True, True, False],
            ],
            dtype=torch.bool,
        ),
        max_budget_by_row=torch.full((2,), 3, dtype=torch.long),
        row_to_graph=torch.zeros(2, dtype=torch.long),
    )

    log_pb = backward_action_log_prob(
        backward_policy=UniformLeafBackwardPolicy(),
        child_state=state,
        context=context,
        action_edge_ids=torch.tensor([0, -1], dtype=torch.long),
    )

    assert torch.allclose(log_pb, torch.tensor([0.0, 0.0]))


def _graph_context() -> GraphContext:
    edge_index = torch.tensor(
        [
            [0, 0, 1],
            [1, 2, 3],
        ],
        dtype=torch.long,
    )
    outgoing_ptr, edge_ids_by_src = build_outgoing_index(
        edge_index=edge_index,
        num_nodes=4,
    )
    return GraphContext(
        edge_index=edge_index,
        node_to_graph=torch.zeros(4, dtype=torch.long),
        edge_to_graph=torch.zeros(3, dtype=torch.long),
        anchor_mask=torch.tensor([True, False, False, False]),
        outgoing_ptr=outgoing_ptr,
        edge_ids_by_src=edge_ids_by_src,
        num_nodes=4,
        num_edges=3,
        num_graphs=1,
    )
